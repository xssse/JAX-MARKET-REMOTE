# JAX REMOTE DESKTOP — Android project scaffold

Status v1.3.0 — **koneksi RDP berjalan lewat aplikasi RDP yang terpasang; layar desktop di dalam JAX belum ada.**

## Cara connect (v1.4.0)
Tekan **Connect** pada koneksi tersimpan -> layar loading penuh dengan 6 tahap yang diperiksa nyata:
1. Jaringan HP (WiFi / Seluler / VPN / Ethernet)
2. Mencari alamat server (DNS)
3. Menghubungi server (TCP, dengan waktu respons)
4. Handshake RDP & keamanan (`RdpProbe.java`: X.224 + RDP Negotiation; terlihat RDP/TLS/NLA)
5. Kredensial (password tersimpan dipakai otomatis; tidak ada prompt)
6. Membuka sesi RDP

Kalau semua tahap OK, sesi langsung dibuka tanpa tap tambahan. Kalau ada tahap yang gagal, tahap itu
ditandai merah beserta penyebabnya, dengan pilihan Coba lagi / Tetap buka / Edit koneksi.
Password tidak perlu diketik lagi: tersimpan terenkripsi (Keystore) per koneksi.

**Batasan saat ini:** sesi dibuka di aplikasi RDP eksternal (mis. Microsoft Remote Desktop) lewat file `.rdp`.
Aplikasi itu tidak bisa menerima password dari JAX, jadi password tersimpan disalin ke clipboard (sensitif,
default aktif, dihapus saat kembali ke JAX) dan tinggal ditempel. Login otomatis penuh di dalam JAX butuh
mesin FreeRDP tertanam (lihat "Build FreeRDP").

## Build FreeRDP (GitHub Actions)
`.github/workflows/build-freerdp-android.yml` membuild FreeRDP di server GitHub dan menghasilkan:
`aFreeRDP-release.apk` (klien RDP resmi untuk dites langsung) dan `freerdp-jniLibs.zip` (library native untuk JAX).
Resep mengikuti README FreeRDP dan Dockerfile pihak ketiga; **workflow ini belum pernah dijalankan**.
Langkah: push project ke GitHub -> Actions -> Build FreeRDP Android -> Run workflow.
Catatan teknis: `LibFreeRDP.java` upstream bergantung pada modul GUI `freeRDPCore` (GlobalApp, SessionState, dll.),
jadi penanaman ke JAX = membawa modul itu atau menulis JNI sendiri. Itu dikerjakan setelah build berhasil.

Jenis koneksi: PC, Laptop, Server/VPS, GitHub/Tunnel. Alamat boleh IP, domain, atau `host:port`
(mis. `0.tcp.ap.ngrok.io:12345` dari RDP GitHub Actions). Port bebas.

Catatan jujur: Microsoft pernah punya bug di versi 10.0.19.x saat membuka file/URI dari luar
(error "We can't connect"). Kalau terjadi, pakai tombol "Buka lewat link rdp://" atau input manual di aplikasinya.

## Tampilan beranda
Beranda berisi daftar kartu RDP (gambar desktop Windows di atas, nama + alamat + user + jenis, tombol Connect,
edit, hapus), filter Semua / Koneksi PC / Koneksi RDP, dan tombol + untuk menambah. Background app polos gelap.
Gambar Windows pada kartu digambar dengan kode (bukan aset Microsoft). Mau gambar sendiri: taruh
`hero_windows.png` di `res/drawable-nodpi/`, otomatis dipakai di semua kartu.

## Bahasa
Pemilih bahasa muncul saat pertama dibuka dan bisa diganti di tab More → Pengaturan → Bahasa
(Ikuti sistem / Bahasa Indonesia / English). Teks sumber berbahasa Indonesia; terjemahan ada di
`EnStrings.kt`. Semua `Text()` otomatis lewat `tr()` (lihat `I18nText.kt`). Bahasa lain: tambah
enum di `AppLang` dan kamus baru dengan pola yang sama.

## Fitur lain yang berfungsi
- Beranda sesuai desain, simpan/edit/hapus koneksi, password terenkripsi (Android Keystore).
- Backup / Restore ke file JSON (passphrase: PBKDF2 + AES-GCM). File backup lama bertanda FRYCO tetap bisa dipulihkan.
- Editor layout tombol custom + mode latihan (More → Layout tombol). Mode latihan memakai
  `PreviewRdpEngine`: **tidak terhubung ke PC**, hanya untuk mengatur tombol.
- Gamepad, Coding keys, side menu, Background Mode (foreground service) di sesi mode latihan.
  Semua ini baru berguna untuk sesi sungguhan setelah mesin RDP tertanam (lihat bawah).

## Yang belum ada: layar desktop di dalam JAX
Ini butuh FreeRDP native (NDK + OpenSSL, dibuild dari source). Bukan dependency Gradle siap pakai.
Rujukan resmi: `docs/README.android` di repo FreeRDP (`scripts/android-build-freerdp.sh --ndk ... --sdk ...`).
Setelah dibuild: implementasikan `RdpEngine` (Rdp.kt), isi `Render()` dengan SurfaceView, ubah
`RdpEngines.create()`. UI sesi (gamepad, custom layout, side menu) sudah memakai interface itu.

## Tes otomatis
`tools/protocol-tests/` berisi tes JVM untuk `RdpProbe` dan `RdpLink` (lihat README di folder itu).
Kode Kotlin/Compose belum pernah dikompilasi oleh saya (tidak ada Android SDK di lingkungan saya).

## Layout tombol custom (v1.2.0)
Side menu sesi → **Custom** (pakai layout tersimpan) atau **Edit tombol** (masuk editor).
Di editor, toolbar ada di samping layar: Batal, Mouse, Keyboard, D-pad, ukuran −/+, Hapus, Simpan, Bantuan.
- Tombol bisa keyboard apa saja (huruf, angka, F1–F12, Shift/Ctrl/Alt, panah…), tombol mouse
  (kiri/kanan/tengah), atau cluster D-pad (WASD / panah).
- Seret untuk memindah, tarik titik biru di pojok untuk ukuran. Posisi disimpan relatif ke layar,
  jadi tetap pas saat HP diputar.
- Satu layout custom per perangkat (disimpan di SharedPreferences `jax_layout`).
- Touch layar tetap jadi pointer di mode Custom, jadi cocok untuk game yang butuh mouse.

## Catatan nama
Nama tampilan: **JAX REMOTE DESKTOP**. Package/applicationId masih `com.fryco.remotedesktop`
supaya tidak jadi aplikasi baru; ganti lewat refactor Android Studio kalau memang mau.

## Build
1. Install Android Studio versi stabil di Windows.
2. Buka folder `JAX-REMOTE-DESKTOP`.
3. Install Android SDK Platform 35 dan JDK 17 jika diminta.
4. Tunggu Gradle Sync.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Integrasi RDP sungguhan (wajib sebelum rilis)
Gunakan source Android resmi FreeRDP:
https://github.com/FreeRDP/FreeRDP/tree/master/client/Android

Dokumen build:
https://github.com/FreeRDP/FreeRDP/blob/master/docs/README.android

FreeRDP Android terdiri dari Java UI, library native, dan JNI. Integrasi bukan
sekadar menambahkan dependency Maven. Porting perlu menyatukan lifecycle sesi,
surface/video rendering, input pointer/keyboard, autentikasi, sertifikat TLS,
dan callback status. Pertahankan lisensi dan pemberitahuan lisensi upstream.

## Fitur yang belum aktif
- Layar desktop di dalam JAX (butuh FreeRDP native).
- Pengiriman input mouse / keyboard / gamepad ke PC dari dalam JAX (kontrak `RdpEngine` sudah ada).
- Audio & Mic dari/ke PC; screen recording MP4 (MediaProjection).

## Catatan host Windows
Remote Desktop bawaan Windows sebagai host memerlukan edisi Pro, Enterprise,
atau Education. Windows Home tidak menerima koneksi RDP masuk dengan fitur
bawaan Microsoft. Periksa Settings > System > About > Windows specifications > Edition.

Jangan membuka port RDP langsung ke internet. Untuk akses luar jaringan, gunakan
VPN tepercaya atau jaringan privat yang dikonfigurasi dengan benar. Jangan simpan
password sebagai teks biasa; gunakan Android Keystore-backed encryption.

## Pengujian yang diperlukan
1. Build dan install pada perangkat Android fisik.
2. Uji LAN ke host Windows yang memang mengaktifkan Remote Desktop.
3. Uji sertifikat, autentikasi, reconnect, dan disconnect.
4. Uji mouse, keyboard, gamepad fisik, dan virtual secara terpisah.
5. Uji perekaman, izin, penyimpanan MP4, dan penghentian service.


## Digital System startup sound
Chime sintetis orisinal di `app/src/main/res/raw/fryco_digital_system.wav`, diputar lokal di HP saat
menekan Connect (volume bawaan 50%, bisa diatur di More). Suara itu bukan tanda sesi sudah tersambung.
