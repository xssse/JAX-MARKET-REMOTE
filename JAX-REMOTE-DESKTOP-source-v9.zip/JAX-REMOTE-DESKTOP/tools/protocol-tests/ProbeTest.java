import com.fryco.remotedesktop.RdpProbe;
import java.io.*;
import java.net.*;
import java.util.*;

public class ProbeTest {
    static int fails = 0;
    static void check(String name, boolean ok) { System.out.println((ok ? "PASS " : "FAIL ") + name); if (!ok) fails++; }

    /** Server tiruan: baca CR, tulis balasan tertentu. */
    static ServerSocket serve(byte[] reply, boolean silent, boolean closeNow, List<byte[]> captured) throws Exception {
        ServerSocket ss = new ServerSocket(0);
        Thread t = new Thread(() -> {
            try (Socket c = ss.accept()) {
                if (closeNow) return;
                byte[] buf = new byte[64]; int n = c.getInputStream().read(buf);
                captured.add(Arrays.copyOf(buf, Math.max(n, 0)));
                if (silent) { Thread.sleep(3000); return; }
                c.getOutputStream().write(reply); c.getOutputStream().flush();
                Thread.sleep(200);
            } catch (Exception e) {}
        });
        t.setDaemon(true); t.start();
        return ss;
    }
    static byte[] hex(String h) { h = h.replace(" ", ""); byte[] b = new byte[h.length()/2]; for (int i=0;i<b.length;i++) b[i]=(byte)Integer.parseInt(h.substring(2*i,2*i+2),16); return b; }

    public static void main(String[] a) throws Exception {
        // 1) Server NLA (CredSSP) — balasan nyata Windows: 03 00 00 13 0e d0 .. 02 00 08 00 02 00 00 00
        List<byte[]> cap = new ArrayList<>();
        ServerSocket s1 = serve(hex("0300 0013 0e d0 0000 1234 00 02 00 0800 02000000"), false, false, cap);
        RdpProbe.Result r = RdpProbe.test("127.0.0.1", s1.getLocalPort(), 2000);
        check("NLA server -> OK + HYBRID(2)", r.status == RdpProbe.Status.OK && r.selectedProtocol == 2);
        // paket yang dikirim klien harus identik dengan capture RDP standar (protokol diminta 0x0B)
        check("CR packet = 03 00 00 13 0e e0 .. 01 00 08 00 0b 00 00 00",
              Arrays.equals(cap.get(0), hex("0300 0013 0e e0 0000 0000 00 01 00 0800 0b000000")));

        // 2) TLS
        ServerSocket s2 = serve(hex("0300 0013 0e d0 0000 1234 00 02 00 0800 01000000"), false, false, new ArrayList<>());
        r = RdpProbe.test("127.0.0.1", s2.getLocalPort(), 2000);
        check("TLS server -> OK + SSL(1)", r.status == RdpProbe.Status.OK && r.selectedProtocol == 1);

        // 3) HYBRID_EX
        ServerSocket s3 = serve(hex("0300 0013 0e d0 0000 1234 00 02 00 0800 08000000"), false, false, new ArrayList<>());
        r = RdpProbe.test("127.0.0.1", s3.getLocalPort(), 2000);
        check("CredSSP+EarlyAuth -> OK + 8", r.status == RdpProbe.Status.OK && r.selectedProtocol == 8);

        // 4) Negotiation failure HYBRID_REQUIRED_BY_SERVER (5)
        ServerSocket s4 = serve(hex("0300 0013 0e d0 0000 1234 00 03 00 0800 05000000"), false, false, new ArrayList<>());
        r = RdpProbe.test("127.0.0.1", s4.getLocalPort(), 2000);
        check("Neg failure code 5", r.status == RdpProbe.Status.NEGOTIATION_FAILED && r.failureCode == 5);

        // 5) Server RDP lama tanpa blok negosiasi
        ServerSocket s5 = serve(hex("0300 000b 06 d0 0000 1234 00"), false, false, new ArrayList<>());
        r = RdpProbe.test("127.0.0.1", s5.getLocalPort(), 2000);
        check("Legacy server (no neg block) -> OK standard", r.status == RdpProbe.Status.OK && r.selectedProtocol == 0);

        // 6) Bukan RDP (HTTP)
        ServerSocket s6 = serve("HTTP/1.1 400 Bad Request\r\n\r\n".getBytes(), false, false, new ArrayList<>());
        r = RdpProbe.test("127.0.0.1", s6.getLocalPort(), 2000);
        check("HTTP server -> NOT_RDP", r.status == RdpProbe.Status.NOT_RDP);

        // 7) Server langsung menutup koneksi
        ServerSocket s7 = serve(new byte[0], false, true, new ArrayList<>());
        r = RdpProbe.test("127.0.0.1", s7.getLocalPort(), 2000);
        check("Closed immediately -> CLOSED/NETWORK", r.status == RdpProbe.Status.CLOSED || r.status == RdpProbe.Status.NETWORK_ERROR);

        // 8) Port tertutup
        ServerSocket tmp = new ServerSocket(0); int dead = tmp.getLocalPort(); tmp.close();
        r = RdpProbe.test("127.0.0.1", dead, 2000);
        check("Closed port -> CONNECTION_REFUSED", r.status == RdpProbe.Status.CONNECTION_REFUSED);

        // 9) Server diam (tunnel setengah hidup)
        ServerSocket s9 = serve(new byte[0], true, false, new ArrayList<>());
        long t0 = System.currentTimeMillis();
        r = RdpProbe.test("127.0.0.1", s9.getLocalPort(), 800);
        check("Silent server -> TIMEOUT (~0.8s)", r.status == RdpProbe.Status.TIMEOUT && System.currentTimeMillis() - t0 < 2500);

        // 10) Host tidak ada
        r = RdpProbe.test("host-yang-tidak-ada.invalid", 3389, 2000);
        check("Bad hostname -> UNKNOWN_HOST", r.status == RdpProbe.Status.UNKNOWN_HOST);

        // 11) Port ngawur
        r = RdpProbe.test("127.0.0.1", 70000, 1000);
        check("Port 70000 -> error handled, no crash", r.status == RdpProbe.Status.NETWORK_ERROR);

        // 12) Listener: urutan tahap resolve -> tcp, dan tahap yang gagal tidak memanggil tahap berikutnya
        final List<String> ev = new ArrayList<>();
        ServerSocket s12 = serve(hex("0300 0013 0e d0 0000 1234 00 02 00 0800 02000000"), false, false, new ArrayList<>());
        RdpProbe.Result r12 = RdpProbe.test("127.0.0.1", s12.getLocalPort(), 2000, new RdpProbe.Listener() {
            public void onResolved(String a, long ms) { ev.add("dns:" + a); }
            public void onTcpConnected(long ms) { ev.add("tcp"); }
        });
        check("Listener order dns -> tcp, hasil OK", ev.equals(Arrays.asList("dns:127.0.0.1", "tcp")) && r12.status == RdpProbe.Status.OK);
        final List<String> ev2 = new ArrayList<>();
        RdpProbe.test("host-yang-tidak-ada.invalid", 3389, 2000, new RdpProbe.Listener() {
            public void onResolved(String a, long ms) { ev2.add("dns"); }
            public void onTcpConnected(long ms) { ev2.add("tcp"); }
        });
        check("DNS gagal -> tidak ada event", ev2.isEmpty());
        final List<String> ev3 = new ArrayList<>();
        ServerSocket tmp2 = new ServerSocket(0); int dead2 = tmp2.getLocalPort(); tmp2.close();
        RdpProbe.test("127.0.0.1", dead2, 2000, new RdpProbe.Listener() {
            public void onResolved(String a, long ms) { ev3.add("dns"); }
            public void onTcpConnected(long ms) { ev3.add("tcp"); }
        });
        check("TCP ditolak -> hanya dns", ev3.equals(Arrays.asList("dns")));

        System.out.println(fails == 0 ? "\nALL PASSED" : "\nFAILED: " + fails);
        System.exit(fails == 0 ? 0 : 1);
    }
}
