package com.fryco.remotedesktop

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

enum class AppLang(val code: String, val label: String) {
    SYSTEM("system", "Ikuti sistem"),
    ID("id", "Bahasa Indonesia"),
    EN("en", "English")
}

/** Pengaturan aplikasi (tersimpan di SharedPreferences "jax_settings"). */
object AppSettings {
    var lang by mutableStateOf(AppLang.SYSTEM)
        private set
    /** false = baru pertama kali dibuka, tampilkan pemilih bahasa. */
    var langChosen by mutableStateOf(true)
        private set
    /** Salin password ke clipboard (ditandai sensitif) tepat sebelum membuka aplikasi RDP. */
    var copyPassword by mutableStateOf(true)
        private set

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("jax_settings", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val p = prefs(ctx)
        val saved = p.getString("lang", null)
        langChosen = saved != null
        lang = AppLang.values().firstOrNull { it.code == saved } ?: AppLang.SYSTEM
        copyPassword = p.getBoolean("copy_password", true)
    }

    fun setLang(ctx: Context, l: AppLang) {
        lang = l
        langChosen = true
        prefs(ctx).edit().putString("lang", l.code).apply()
    }

    fun setCopyPassword(ctx: Context, on: Boolean) {
        copyPassword = on
        prefs(ctx).edit().putBoolean("copy_password", on).apply()
    }
}

object I18n {
    val effective: AppLang
        get() {
            val l = AppSettings.lang
            if (l != AppLang.SYSTEM) return l
            val c = Locale.getDefault().language
            return if (c == "id" || c == "in") AppLang.ID else AppLang.EN
        }
}

/** Teks sumber ditulis dalam Bahasa Indonesia. Bahasa Inggris dicari di EnStrings; tidak ketemu = tetap apa adanya. */
fun tr(s: String): String = if (I18n.effective == AppLang.EN) EnStrings.map[s] ?: s else s

/** Versi dengan argumen (format String.format). Kunci kamus = string format Indonesia. */
fun trf(fmt: String, vararg args: Any?): String = String.format(tr(fmt), *args)
