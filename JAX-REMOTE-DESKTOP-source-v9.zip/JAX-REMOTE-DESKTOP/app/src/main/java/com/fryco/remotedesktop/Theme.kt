package com.fryco.remotedesktop

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/** Palet JAX: hitam pekat + cyan/biru neon, hijau untuk "connected", ungu untuk aksi sekunder. */
object Fx {
    val Bg = Color(0xFF05070C)
    val Panel = Color(0xFF0B121C)
    val PanelHi = Color(0xFF111B2A)
    val Neon = Color(0xFF22C7FF)
    val Blue = Color(0xFF2A6BFF)
    val Violet = Color(0xFF7A3BFF)
    val Green = Color(0xFF3DDC84)
    val Red = Color(0xFFFF4D5E)
    val Muted = Color(0xFF8FA3B8)
    val Line = Color(0xFF173A52)
}

fun Modifier.neonPanel(
    shape: Shape,
    accent: Color = Fx.Neon,
    fill: Brush = Brush.verticalGradient(listOf(Fx.PanelHi.copy(alpha = 0.86f), Fx.Panel.copy(alpha = 0.90f)))
): Modifier = this
    .clip(shape)
    .background(fill, shape)
    .border(1.dp, accent.copy(alpha = 0.45f), shape)
