package com.fryco.remotedesktop

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class StepState { PENDING, RUNNING, OK, WARN, FAILED }

private class StepUi(val title: String) {
    var state by mutableStateOf(StepState.PENDING)
    var detail by mutableStateOf("")
}

private fun networkInfo(ctx: Context): Pair<Boolean, String> {
    val none = tr("Tidak ada koneksi. Nyalakan WiFi atau data seluler.")
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val net = cm.activeNetwork ?: return false to none
    val caps = cm.getNetworkCapabilities(net) ?: return false to none
    val kind = when {
        caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WiFi"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> tr("Seluler")
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
        else -> tr("Jaringan")
    }
    return true to kind
}

/**
 * Layar loading saat Connect: memeriksa tiap tahap secara nyata dan menunjukkan hasilnya.
 * Password tersimpan dipakai otomatis (tidak ada prompt). Jika semua tahap OK, sesi langsung dibuka
 * tanpa tap tambahan. Jika ada yang gagal, tahap yang bermasalah ditandai dan user bisa coba lagi / edit.
 */
@Composable
fun ConnectingScreen(c: SavedConnection, password: String, onClose: () -> Unit, onEdit: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val steps = remember {
        listOf(
            StepUi("Memeriksa jaringan HP"),
            StepUi("Mencari alamat server"),
            StepUi("Menghubungi server"),
            StepUi("Handshake RDP & keamanan"),
            StepUi("Kredensial"),
            StepUi("Membuka sesi RDP")
        )
    }
    var attempt by remember { mutableIntStateOf(0) }
    var failed by remember { mutableStateOf(false) }
    var noApp by remember { mutableStateOf(false) }

    BackHandler(onBack = onClose)

    fun openSession(): Boolean {
        if (AppSettings.copyPassword && password.isNotEmpty()) ExternalRdp.copyPassword(ctx, password)
        return ExternalRdp.openFile(ctx, c.host, c.port, c.username) || ExternalRdp.openUri(ctx, c.host, c.port, c.username)
    }

    suspend fun launchSession() {
        failed = false
        noApp = false
        steps[5].state = StepState.RUNNING
        steps[5].detail = ""
        delay(500)
        if (openSession()) {
            steps[5].state = StepState.OK
            steps[5].detail = tr("Sesi dibuka di aplikasi RDP")
            delay(600)
            onClose()
        } else {
            steps[5].state = StepState.FAILED
            steps[5].detail = tr("Tidak ada aplikasi RDP yang bisa membuka sesi ini. Pasang Microsoft Remote Desktop dulu.")
            failed = true
            noApp = true
        }
    }

    LaunchedEffect(attempt) {
        steps.forEach { it.state = StepState.PENDING; it.detail = "" }
        failed = false
        noApp = false

        // 1) jaringan HP
        steps[0].state = StepState.RUNNING
        delay(250)
        val net = networkInfo(ctx)
        if (!net.first) {
            steps[0].state = StepState.FAILED
            steps[0].detail = net.second
            failed = true
            return@LaunchedEffect
        }
        steps[0].state = StepState.OK
        steps[0].detail = net.second

        // 2-4) DNS -> TCP -> handshake RDP (nyata)
        steps[1].state = StepState.RUNNING
        var resolved = false
        var connected = false
        val r = withContext(Dispatchers.IO) {
            RdpProbe.test(c.host, c.port, 6000, object : RdpProbe.Listener {
                override fun onResolved(address: String, millis: Long) {
                    resolved = true
                    steps[1].state = StepState.OK
                    steps[1].detail = "$address • $millis ms"
                    steps[2].state = StepState.RUNNING
                }

                override fun onTcpConnected(millis: Long) {
                    connected = true
                    steps[2].state = StepState.OK
                    steps[2].detail = "${c.port} • $millis ms"
                    steps[3].state = StepState.RUNNING
                }
            })
        }
        val (title, detail) = describeProbe(r)
        if (r.status == RdpProbe.Status.OK) {
            steps[3].state = StepState.OK
            steps[3].detail = detail
        } else {
            val bad = when {
                !resolved -> steps[1]
                !connected -> steps[2]
                else -> steps[3]
            }
            bad.state = StepState.FAILED
            bad.detail = "$title — $detail"
            failed = true
            return@LaunchedEffect
        }

        // 5) kredensial
        delay(200)
        if (password.isNotEmpty()) {
            steps[4].state = StepState.OK
            steps[4].detail = tr("Password tersimpan, dipakai otomatis")
        } else {
            steps[4].state = StepState.WARN
            steps[4].detail = tr("Tidak ada password tersimpan; akan diminta di aplikasi RDP")
        }

        // 6) buka sesi
        launchSession()
    }

    val done = steps.count { it.state == StepState.OK || it.state == StepState.WARN }
    val allOk = done == steps.size

    Box(Modifier.fillMaxSize().background(Fx.Bg).statusBarsPadding().navigationBarsPadding()) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                if (failed) "Ada masalah" else if (allOk) "Siap" else "Menyambungkan…",
                color = if (failed) Fx.Red else Fx.Neon, fontSize = 26.sp, fontWeight = FontWeight.Black
            )
            Column(Modifier.fillMaxWidth().neonPanel(RoundedCornerShape(18.dp)).padding(16.dp)) {
                Text(c.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("${c.username.ifEmpty { "—" }} @ ${c.host}:${c.port}", color = Fx.Muted, fontSize = 13.sp)
            }
            LinearProgressIndicator(
                progress = { done.toFloat() / steps.size },
                modifier = Modifier.fillMaxWidth().height(6.dp),
                color = if (failed) Fx.Red else Fx.Neon, trackColor = Color(0xFF1B2636)
            )
            Column(
                Modifier.fillMaxWidth().neonPanel(RoundedCornerShape(18.dp)).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                steps.forEach { StepRow(it) }
            }
            if (failed) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    TextButton({ attempt++ }) { Text("Coba lagi", color = Fx.Neon, fontWeight = FontWeight.Bold) }
                    if (!noApp) TextButton({ scope.launch { launchSession() } }) {
                        Text("Tetap buka di aplikasi RDP", color = Fx.Neon)
                    }
                    TextButton(onEdit) { Text("Edit koneksi", color = Fx.Muted) }
                }
                if (noApp) {
                    Button(
                        { ExternalRdp.openStore(ctx) },
                        colors = ButtonDefaults.buttonColors(containerColor = Fx.Neon, contentColor = Fx.Bg)
                    ) { Text("Buka Play Store") }
                }
            }
            Spacer(Modifier.weight(1f, fill = false))
            TextButton(onClose, Modifier.fillMaxWidth()) {
                Text(if (failed || allOk) "Tutup" else "Batal", color = Fx.Muted)
            }
        }
    }
}

@Composable
private fun StepRow(s: StepUi) {
    Row(verticalAlignment = Alignment.Top) {
        Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
            when (s.state) {
                StepState.PENDING -> Box(Modifier.size(10.dp).border(1.5.dp, Fx.Muted.copy(alpha = 0.6f), CircleShape))
                StepState.RUNNING -> CircularProgressIndicator(Modifier.size(18.dp), color = Fx.Neon, strokeWidth = 2.dp)
                StepState.OK -> Icon(Icons.Default.Check, null, tint = Fx.Green, modifier = Modifier.size(20.dp))
                StepState.WARN -> Icon(Icons.Default.Info, null, tint = Color(0xFFFFC857), modifier = Modifier.size(20.dp))
                StepState.FAILED -> Icon(Icons.Default.Close, null, tint = Fx.Red, modifier = Modifier.size(20.dp))
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                s.title,
                color = if (s.state == StepState.PENDING) Fx.Muted else Color.White,
                fontSize = 15.sp, fontWeight = FontWeight.SemiBold
            )
            if (s.detail.isNotEmpty()) {
                Text(
                    s.detail, fontSize = 12.sp,
                    color = when (s.state) {
                        StepState.FAILED -> Fx.Red
                        StepState.WARN -> Color(0xFFFFC857)
                        else -> Fx.Muted
                    }
                )
            }
        }
    }
}
