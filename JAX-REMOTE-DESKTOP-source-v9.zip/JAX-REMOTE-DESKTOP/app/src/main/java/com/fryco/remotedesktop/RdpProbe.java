package com.fryco.remotedesktop;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NoRouteToHostException;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

/**
 * Tes koneksi RDP yang NYATA (tanpa login): TCP connect, lalu kirim X.224 Connection Request
 * dengan RDP Negotiation Request (MS-RDPBCGR 2.2.1.1) dan baca balasannya. Dari situ kelihatan:
 * host bisa dijangkau, benar-benar server RDP, dan mode keamanan yang dipilih (RDP/TLS/NLA).
 * Java murni tanpa dependensi Android supaya bisa dites di JVM biasa.
 */
public final class RdpProbe {
    public enum Status {
        OK, NEGOTIATION_FAILED, NOT_RDP, CONNECTION_REFUSED, TIMEOUT, UNKNOWN_HOST, NETWORK_ERROR, CLOSED
    }

    public static final int PROTO_RDP = 0, PROTO_SSL = 1, PROTO_HYBRID = 2, PROTO_RDSTLS = 4, PROTO_HYBRID_EX = 8;

    public static final class Result {
        public final Status status;
        public final int selectedProtocol;
        public final int failureCode;
        public final long millis;
        public final String detail;

        Result(Status status, int selectedProtocol, int failureCode, long millis, String detail) {
            this.status = status;
            this.selectedProtocol = selectedProtocol;
            this.failureCode = failureCode;
            this.millis = millis;
            this.detail = detail == null ? "" : detail;
        }
    }

    /** Dipanggil dari thread yang menjalankan test() saat tiap tahap selesai. */
    public interface Listener {
        void onResolved(String address, long millis);
        void onTcpConnected(long millis);
    }

    private RdpProbe() {}

    /** TPKT + X.224 CR + RDP_NEG_REQ(SSL | HYBRID | HYBRID_EX). Tanpa cookie, jadi username tidak bocor. */
    static byte[] buildConnectionRequest() {
        int li = 6 + 8;          // X.224 tetap (6, tidak termasuk byte LI) + RDP_NEG_REQ (8)
        int total = 4 + 1 + li;  // TPKT(4) + LI(1) + li
        byte[] p = new byte[total];
        p[0] = 0x03;             // TPKT version
        p[1] = 0x00;
        p[2] = (byte) (total >> 8);
        p[3] = (byte) total;
        p[4] = (byte) li;        // length indicator
        p[5] = (byte) 0xE0;      // CR TPDU
        // dst-ref(2)=0, src-ref(2)=0, class(1)=0 -> p[6..10] = 0
        p[11] = 0x01;            // TYPE_RDP_NEG_REQ
        p[12] = 0x00;            // flags
        p[13] = 0x08;            // length LE = 8
        p[14] = 0x00;
        int req = PROTO_SSL | PROTO_HYBRID | PROTO_HYBRID_EX;
        p[15] = (byte) req;      // requestedProtocols LE
        p[16] = 0; p[17] = 0; p[18] = 0;
        return p;
    }

    /** Parse balasan setelah header TPKT dibaca. body = isi TPKT tanpa 4 byte header. */
    static Result parseBody(byte[] body, long millis) {
        if (body.length < 6) return new Result(Status.NOT_RDP, 0, 0, millis, "short");
        int code = body[1] & 0xF0;
        if (code == 0x80) return new Result(Status.CLOSED, 0, 0, millis, "disconnect request");
        if (code != 0xD0) return new Result(Status.NOT_RDP, 0, 0, millis, "tpdu=" + code);
        // Tanpa blok negosiasi = server RDP lama (protokol standar).
        if (body.length < 7 + 8) return new Result(Status.OK, PROTO_RDP, 0, millis, "legacy");
        int type = body[7] & 0xFF;
        int value = (body[11] & 0xFF) | ((body[12] & 0xFF) << 8) | ((body[13] & 0xFF) << 16) | ((body[14] & 0xFF) << 24);
        if (type == 0x02) return new Result(Status.OK, value, 0, millis, "");
        if (type == 0x03) return new Result(Status.NEGOTIATION_FAILED, 0, value, millis, "");
        return new Result(Status.OK, PROTO_RDP, 0, millis, "no-neg");
    }

    public static Result test(String host, int port, int timeoutMs) {
        return test(host, port, timeoutMs, null);
    }

    /** Tahap: (1) resolve DNS, (2) TCP connect, (3) negosiasi RDP. Listener opsional untuk laporan per tahap. */
    public static Result test(String host, int port, int timeoutMs, Listener listener) {
        long t0 = System.nanoTime();
        try (Socket s = new Socket()) {
            InetAddress addr = InetAddress.getByName(host);
            if (listener != null) listener.onResolved(addr.getHostAddress(), (System.nanoTime() - t0) / 1_000_000L);
            long t1 = System.nanoTime();
            s.connect(new InetSocketAddress(addr, port), timeoutMs);
            if (listener != null) listener.onTcpConnected((System.nanoTime() - t1) / 1_000_000L);
            s.setSoTimeout(timeoutMs);
            s.setTcpNoDelay(true);
            OutputStream out = s.getOutputStream();
            out.write(buildConnectionRequest());
            out.flush();
            DataInputStream in = new DataInputStream(s.getInputStream());
            byte[] hdr = new byte[4];
            in.readFully(hdr);
            long ms = (System.nanoTime() - t0) / 1_000_000L;
            if ((hdr[0] & 0xFF) != 0x03) return new Result(Status.NOT_RDP, 0, 0, ms, "bad tpkt");
            int len = ((hdr[2] & 0xFF) << 8) | (hdr[3] & 0xFF);
            if (len < 11 || len > 1024) return new Result(Status.NOT_RDP, 0, 0, ms, "bad length " + len);
            byte[] body = new byte[len - 4];
            in.readFully(body);
            return parseBody(body, ms);
        } catch (UnknownHostException e) {
            return fail(Status.UNKNOWN_HOST, t0, e);
        } catch (ConnectException e) {
            String m = String.valueOf(e.getMessage()).toLowerCase();
            return fail(m.contains("timed out") ? Status.TIMEOUT : Status.CONNECTION_REFUSED, t0, e);
        } catch (SocketTimeoutException e) {
            return fail(Status.TIMEOUT, t0, e);
        } catch (NoRouteToHostException e) {
            return fail(Status.NETWORK_ERROR, t0, e);
        } catch (java.io.EOFException e) {
            return fail(Status.CLOSED, t0, e);
        } catch (IOException e) {
            return fail(Status.NETWORK_ERROR, t0, e);
        } catch (IllegalArgumentException e) { // port di luar range
            return fail(Status.NETWORK_ERROR, t0, e);
        }
    }

    private static Result fail(Status st, long t0, Exception e) {
        return new Result(st, 0, 0, (System.nanoTime() - t0) / 1_000_000L, e.getClass().getSimpleName() + ": " + e.getMessage());
    }
}
