package com.fryco.remotedesktop

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Cek apakah host:port bisa dijangkau (TCP connect singkat). Hanya indikator, bukan login. */
private fun probe(host: String, port: Int): Boolean = try {
    Socket().use { it.connect(InetSocketAddress(host, port), 1500); true }
} catch (e: Exception) {
    false
}

@Composable
private fun rememberReachability(items: List<SavedConnection>): Map<String, Boolean> {
    val map = remember { mutableStateMapOf<String, Boolean>() }
    val key = items.joinToString("|") { it.id + it.host + it.port }
    LaunchedEffect(key) {
        items.forEach { c -> launch(Dispatchers.IO) { map[c.id] = probe(c.host, c.port) } }
    }
    return map
}

@Composable
fun MainShell(repo: ConnectionRepo, sound: SoundPrefs) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<SavedConnection?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<SavedConnection?>(null) }
    var askPassword by remember { mutableStateOf<SavedConnection?>(null) }
    var showBackup by remember { mutableStateOf(false) }
    var backupPass by remember { mutableStateOf("") }
    var restoreText by remember { mutableStateOf<String?>(null) }

    fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()

    fun startConnect(c: SavedConnection, pw: String) {
        sound.playStartup()
        repo.save(c.copy(lastUsed = System.currentTimeMillis()))
        SessionManager.connect(ctx, RdpProfile(c.name, c.host, c.port, c.username, pw))
    }

    fun tryConnect(c: SavedConnection) {
        val pw = repo.password(c)
        if (pw.isEmpty()) askPassword = c else startConnect(c, pw)
    }

    val createLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use {
                    it.write(repo.exportJson(backupPass).toByteArray(Charsets.UTF_8))
                }
                toast("Backup tersimpan (${repo.items.size} koneksi).")
            } catch (e: Exception) {
                toast("Backup gagal: ${e.message}")
            }
        }
        backupPass = ""
    }
    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = try {
                ctx.contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) }
            } catch (e: Exception) {
                null
            }
            when (text?.let { repo.backupNeedsPassphrase(it) }) {
                null -> toast("File itu bukan backup JAX.")
                false -> {
                    val r = repo.importJson(text!!, "")
                    toast(r.error ?: "Dipulihkan: ${r.added} baru, ${r.updated} diperbarui.")
                }
                true -> restoreText = text
            }
        }
    }
    val startBackup = { showBackup = true }
    val startRestore = { openLauncher.launch(arrayOf("application/json", "application/octet-stream", "text/plain")) }
    val newConnection = { editing = null; showEditor = true }

    Scaffold(
        containerColor = Fx.Bg,
        bottomBar = { FrycoBottomBar(tab, { tab = it }, newConnection) }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeTab(
                    repo, onNew = newConnection, onPlay = ::tryConnect,
                    onEdit = { editing = it; showEditor = true }, onDelete = { deleting = it },
                    onBackup = startBackup, onRestore = startRestore, onSettings = { tab = 3 }
                )
                1 -> SessionsTab(repo, ::tryConnect)
                2 -> AboutTab()
                else -> MoreTab(sound, repo.items.size, startBackup, startRestore)
            }
        }
    }

    if (showEditor) {
        ConnectionEditor(
            existing = editing,
            onDismiss = { showEditor = false },
            onSave = { c, connect, typedPw ->
                showEditor = false
                repo.save(c)
                if (connect) {
                    val pw = typedPw.ifEmpty { repo.password(c) }
                    if (pw.isEmpty()) askPassword = c else startConnect(c, pw)
                }
            }
        )
    }
    deleting?.let { c ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            containerColor = Fx.Panel,
            title = { Text("Hapus koneksi?", color = Color.White) },
            text = { Text("“${c.name}” akan dihapus dari daftar tersimpan di HP ini. PC-nya tidak terpengaruh.", color = Fx.Muted) },
            confirmButton = { TextButton({ repo.delete(c.id); deleting = null }) { Text("Hapus", color = Fx.Red) } },
            dismissButton = { TextButton({ deleting = null }) { Text("Batal", color = Fx.Muted) } }
        )
    }
    askPassword?.let { c ->
        PasswordPrompt(c, onDismiss = { askPassword = null }) { pw ->
            askPassword = null
            startConnect(c, pw)
        }
    }
    if (showBackup) {
        PassphraseDialog(
            title = "Backup koneksi",
            note = "Isi passphrase supaya password ikut tersimpan (terenkripsi). Kosongkan kalau mau backup tanpa password.",
            confirmLabel = "Simpan file",
            onDismiss = { showBackup = false },
        ) { pass ->
            showBackup = false
            backupPass = pass
            val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
            createLauncher.launch("jax-backup-$stamp.json")
        }
    }
    restoreText?.let { text ->
        PassphraseDialog(
            title = "Pulihkan backup",
            note = "File ini terenkripsi. Masukkan passphrase yang dipakai saat backup.",
            confirmLabel = "Pulihkan",
            onDismiss = { restoreText = null },
        ) { pass ->
            val r = repo.importJson(text, pass)
            if (r.error != null) toast(r.error) else {
                restoreText = null
                toast("Dipulihkan: ${r.added} baru, ${r.updated} diperbarui.")
            }
        }
    }
}

// ───────────────────────── Home ─────────────────────────

@Composable
private fun HomeTab(
    repo: ConnectionRepo,
    onNew: () -> Unit,
    onPlay: (SavedConnection) -> Unit,
    onEdit: (SavedConnection) -> Unit,
    onDelete: (SavedConnection) -> Unit,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onSettings: () -> Unit
) {
    val reach = rememberReachability(repo.items)
    var showAll by remember { mutableStateOf(false) }
    val list = if (showAll) repo.items.toList() else repo.items.take(3)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Hero(onSettings)
        Column(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            StatusCard(onNew)

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Saved Connections", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(10.dp))
                Box(
                    Modifier.background(Color(0xFF16233A), CircleShape).padding(horizontal = 10.dp, vertical = 3.dp)
                ) { Text("${repo.items.size}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.weight(1f))
                if (repo.items.size > 3) {
                    Text(
                        if (showAll) "Ringkas" else "Lihat Semua",
                        color = Fx.Neon, fontSize = 13.sp,
                        modifier = Modifier.clickable { showAll = !showAll }
                    )
                }
            }

            if (repo.items.isEmpty()) {
                Box(
                    Modifier.fillMaxWidth().neonPanel(RoundedCornerShape(18.dp)).padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Belum ada koneksi tersimpan.\nTekan Connect atau tombol J untuk menambah PC / laptop.",
                        color = Fx.Muted, fontSize = 13.sp
                    )
                }
            }
            list.forEach { c ->
                ConnectionRow(c, reach[c.id], { onPlay(c) }, { onEdit(c) }, { onDelete(c) })
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionTile("Backup", "Simpan daftar ke file", Icons.Default.Backup, Modifier.weight(1f), onBackup)
                ActionTile("Restore", "Pulihkan dari file", Icons.Default.Restore, Modifier.weight(1f), onRestore)
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun Hero(onSettings: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(250.dp)) {
        Canvas(Modifier.fillMaxSize()) {
            // glow latar
            drawRect(
                Brush.radialGradient(
                    listOf(Fx.Blue.copy(alpha = 0.55f), Color.Transparent),
                    center = Offset(size.width * 0.78f, size.height * 0.45f), radius = size.width * 0.7f
                )
            )
            // monitor
            val mx = size.width * 0.50f; val my = size.height * 0.18f
            val mw = size.width * 0.42f; val mh = size.height * 0.40f
            drawRoundRect(
                Brush.linearGradient(listOf(Color(0xFF0B2A66), Color(0xFF0A1020))),
                Offset(mx, my), Size(mw, mh), CornerRadius(14f)
            )
            drawRoundRect(Fx.Neon, Offset(mx, my), Size(mw, mh), CornerRadius(14f), style = Stroke(3f))
            drawRect(Fx.Neon.copy(alpha = 0.7f), Offset(mx + mw * 0.45f, my + mh), Size(mw * 0.1f, size.height * 0.07f))
            drawRoundRect(Fx.Neon.copy(alpha = 0.7f), Offset(mx + mw * 0.30f, my + mh + size.height * 0.07f), Size(mw * 0.4f, 6f), CornerRadius(3f))
            // tower
            val tx = mx + mw + size.width * 0.02f
            drawRoundRect(Color(0xFF0A1020), Offset(tx, my + mh * 0.15f), Size(size.width * 0.12f, mh * 1.1f), CornerRadius(10f))
            drawRoundRect(Fx.Neon, Offset(tx, my + mh * 0.15f), Size(size.width * 0.12f, mh * 1.1f), CornerRadius(10f), style = Stroke(3f))
            drawCircle(Fx.Neon, 9f, Offset(tx + size.width * 0.06f, my + mh * 0.75f), alpha = 0.9f)
            // garis lantai bercahaya
            drawLine(
                Brush.horizontalGradient(listOf(Color.Transparent, Fx.Neon, Color.Transparent)),
                Offset(size.width * 0.2f, size.height * 0.82f), Offset(size.width, size.height * 0.82f), 3f
            )
        }
        // fade bawah supaya menyatu dengan latar
        Box(
            Modifier.fillMaxWidth().height(90.dp).align(Alignment.BottomCenter)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Fx.Bg)))
        )
        Column(Modifier.padding(start = 18.dp, top = 14.dp)) {
            Text(
                "JAX",
                style = TextStyle(
                    brush = Brush.horizontalGradient(listOf(Color.White, Fx.Neon)),
                    fontSize = 54.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic,
                    letterSpacing = 1.sp
                )
            )
            Text(
                "REMOTE DESKTOP", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                fontStyle = FontStyle.Italic, letterSpacing = 2.sp, modifier = Modifier.padding(start = 28.dp)
            )
        }
        IconButton(onClick = onSettings, modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)) {
            Icon(Icons.Default.Settings, "Pengaturan", tint = Color.White)
        }
        Column(Modifier.align(Alignment.BottomStart).padding(start = 18.dp, bottom = 14.dp)) {
            Text(
                "Connect • Control • Explore", color = Fx.Neon, fontSize = 18.sp, fontWeight = FontWeight.SemiBold
            )
            Text("RDP Client for Android", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
        }
    }
}

@Composable
private fun StatusCard(onConnect: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().neonPanel(RoundedCornerShape(20.dp), accent = Fx.Blue).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.DesktopWindows, null, tint = Fx.Neon, modifier = Modifier.size(46.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("Not Connected", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text("Silakan hubungkan ke PC atau laptop terlebih dahulu.", color = Fx.Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.width(10.dp))
        Row(
            Modifier.clip(RoundedCornerShape(16.dp)).border(1.5.dp, Fx.Neon, RoundedCornerShape(16.dp)).clickable(onClick = onConnect)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Bolt, null, tint = Fx.Neon)
            Spacer(Modifier.width(6.dp))
            Text("Connect", color = Fx.Neon, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ConnectionRow(
    c: SavedConnection, online: Boolean?,
    onPlay: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().neonPanel(RoundedCornerShape(18.dp)).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(46.dp).background(Color(0xFF0E2238), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(if (c.kind == "LAPTOP") Icons.Default.Laptop else Icons.Default.DesktopWindows, null, tint = Fx.Neon)
        }
        Spacer(Modifier.width(10.dp))
        Box(
            Modifier.size(9.dp).background(
                when (online) { true -> Fx.Green; false -> Color(0xFF4A5668); null -> Color(0xFF2A3647) }, CircleShape
            )
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(c.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1)
            Text("${c.host} • ${c.port}", color = Fx.Muted, fontSize = 13.sp, maxLines = 1)
        }
        IconButton(onClick = onPlay, modifier = Modifier.size(42.dp).border(1.5.dp, Fx.Neon, CircleShape)) {
            Icon(Icons.Default.PlayArrow, "Connect", tint = Fx.Neon)
        }
        IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, "Edit", tint = Fx.Muted) }
        IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Hapus", tint = Fx.Muted) }
    }
}

@Composable
private fun ActionTile(title: String, sub: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.neonPanel(RoundedCornerShape(18.dp), accent = Fx.Violet).clickable(onClick = onClick).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(icon, null, tint = Fx.Neon, modifier = Modifier.size(28.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text(sub, color = Fx.Muted, fontSize = 11.sp)
    }
}

// ───────────────────────── Tab lain ─────────────────────────

@Composable
private fun SessionsTab(repo: ConnectionRepo, onPlay: (SavedConnection) -> Unit) {
    val recent = repo.items.filter { it.lastUsed > 0 }.sortedByDescending { it.lastUsed }
    val fmt = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Sessions", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
        Text("Koneksi yang terakhir dipakai. Tekan play untuk masuk lagi tanpa mengetik ulang.", color = Fx.Muted, fontSize = 13.sp)
        if (recent.isEmpty()) Text("Belum ada riwayat sesi.", color = Fx.Muted, fontSize = 14.sp)
        recent.forEach { c ->
            Row(
                Modifier.fillMaxWidth().neonPanel(RoundedCornerShape(18.dp)).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(c.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("${c.host}:${c.port} • ${fmt.format(Date(c.lastUsed))}", color = Fx.Muted, fontSize = 12.sp)
                }
                IconButton(onClick = { onPlay(c) }, modifier = Modifier.size(42.dp).border(1.5.dp, Fx.Neon, CircleShape)) {
                    Icon(Icons.Default.PlayArrow, "Connect", tint = Fx.Neon)
                }
            }
        }
    }
}

@Composable
private fun AboutTab() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("About", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
        Column(Modifier.fillMaxWidth().neonPanel(RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("JAX REMOTE DESKTOP", color = Fx.Neon, fontWeight = FontWeight.Bold)
            Text("Versi 1.2.0", color = Color.White, fontSize = 13.sp)
            Text(
                if (RdpEngines.IS_REAL) "Mesin RDP: aktif" else "Mesin RDP: belum terpasang (mode pratinjau UI). Koneksi sungguhan butuh integrasi FreeRDP — lihat RDP_INTEGRATION_NOTES.md.",
                color = if (RdpEngines.IS_REAL) Fx.Green else Fx.Muted, fontSize = 12.sp
            )
        }
        Column(Modifier.fillMaxWidth().neonPanel(RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Keamanan", color = Fx.Neon, fontWeight = FontWeight.Bold)
            Text("• Password disimpan terenkripsi (Android Keystore), tidak pernah sebagai teks biasa.", color = Fx.Muted, fontSize = 12.sp)
            Text("• Jangan membuka port 3389 langsung ke internet. Untuk akses dari luar WiFi, pakai VPN (Tailscale / ZeroTier / WireGuard).", color = Fx.Muted, fontSize = 12.sp)
            Text("• Windows Home tidak bisa jadi host RDP; perlu Pro/Enterprise/Education.", color = Fx.Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun MoreTab(sound: SoundPrefs, count: Int, onBackup: () -> Unit, onRestore: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("More", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
        Column(Modifier.fillMaxWidth().neonPanel(RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Backup & Restore", color = Fx.Neon, fontWeight = FontWeight.Bold)
            Text("$count koneksi tersimpan. Backup supaya tidak perlu input ulang saat ganti HP atau install ulang.", color = Fx.Muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onBackup, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Fx.Neon, contentColor = Fx.Bg)) { Text("Backup") }
                Button(onRestore, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Fx.Violet, contentColor = Color.White)) { Text("Restore") }
            }
        }
        Column(Modifier.fillMaxWidth().neonPanel(RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Audio & Sound", color = Fx.Neon, fontWeight = FontWeight.Bold)
            SwitchRow("Startup Sound", "Digital System saat menekan connect", sound.startup) { sound.startup = it; sound.save() }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Startup Volume", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                Text("${(sound.volume * 100).toInt()}%", color = Fx.Neon, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = sound.volume, onValueChange = { sound.volume = it }, onValueChangeFinished = { sound.save() },
                colors = SliderDefaults.colors(thumbColor = Fx.Neon, activeTrackColor = Fx.Neon)
            )
            SwitchRow("Connection Sound", "Disiapkan; aktif setelah mesin RDP asli terpasang", sound.connection) { sound.connection = it; sound.save() }
            SwitchRow("Disconnect Sound", "Disiapkan; aktif setelah mesin RDP asli terpasang", sound.disconnect) { sound.disconnect = it; sound.save() }
            HorizontalDivider(color = Color(0xFF263548))
            SwitchRow("Mute All Sounds", "Matikan semua efek suara JAX", sound.muteAll) { sound.muteAll = it; sound.save() }
        }
    }
}

// ───────────────────────── Bottom bar ─────────────────────────

@Composable
private fun FrycoBottomBar(selected: Int, onSelect: (Int) -> Unit, onCenter: () -> Unit) {
    Box(Modifier.fillMaxWidth().background(Color(0xFF070B12)).navigationBarsPadding()) {
        HorizontalDivider(color = Fx.Line)
        Row(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            NavItem("Home", Icons.Default.Home, selected == 0, Modifier.weight(1f)) { onSelect(0) }
            NavItem("Sessions", Icons.Default.History, selected == 1, Modifier.weight(1f)) { onSelect(1) }
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.offset(y = (-14).dp).size(64.dp)
                        .background(Brush.linearGradient(listOf(Fx.Blue, Fx.Neon)), RoundedCornerShape(22.dp))
                        .border(2.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(22.dp))
                        .clickable(onClick = onCenter),
                    contentAlignment = Alignment.Center
                ) {
                    Text("J", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
                }
            }
            NavItem("About", Icons.Default.Info, selected == 2, Modifier.weight(1f)) { onSelect(2) }
            NavItem("More", Icons.Default.MoreHoriz, selected == 3, Modifier.weight(1f)) { onSelect(3) }
        }
    }
}

@Composable
private fun NavItem(label: String, icon: ImageVector, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick).padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, label, tint = if (active) Fx.Neon else Fx.Muted)
        Text(label, color = if (active) Fx.Neon else Fx.Muted, fontSize = 11.sp)
    }
}
