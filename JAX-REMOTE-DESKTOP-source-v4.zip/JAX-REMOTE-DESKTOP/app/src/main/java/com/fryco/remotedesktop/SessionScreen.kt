package com.fryco.remotedesktop

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.os.Build
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Minimize
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

enum class InputMode { MOUSE, GAMEPAD, CODING, CUSTOM }

/** Scan code PS/2 set 1. Extended key = 0xE000 or kode. */
object Sc {
    const val ESC = 0x01; const val BKSP = 0x0E; const val TAB = 0x0F; const val ENTER = 0x1C
    const val CTRL = 0x1D; const val SHIFT = 0x2A; const val ALT = 0x38
    const val C = 0x2E; const val V = 0x2F; const val Z = 0x2C; const val S = 0x1F
    const val HOME = 0xE047; const val UP = 0xE048; const val PGUP = 0xE049; const val LEFT = 0xE04B
    const val RIGHT = 0xE04D; const val END = 0xE04F; const val DOWN = 0xE050; const val PGDN = 0xE051
    const val INS = 0xE052; const val DEL = 0xE053; const val WIN = 0xE05B
    fun f(n: Int) = if (n <= 10) 0x3A + n else 0x57 + (n - 11)
}

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun SessionScreen() {
    val ctx = LocalContext.current
    val activity = remember(ctx) { ctx.findActivity() }
    val engine = SessionManager.engine ?: return
    val profile = SessionManager.profile

    var panelOpen by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf(InputMode.MOUSE) }
    var keyboardOn by remember { mutableStateOf(false) }
    var scale by remember { mutableFloatStateOf(1f) }
    var landscape by remember { mutableStateOf(false) }
    var confirmDisconnect by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }
    var custom by remember { mutableStateOf(LayoutStore.load(ctx)) }

    // Layar penuh + layar tetap menyala selama sesi.
    DisposableEffect(activity) {
        val w = activity?.window
        if (w != null) {
            w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            val c = WindowCompat.getInsetsController(w, w.decorView)
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            if (w != null) {
                w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                WindowCompat.getInsetsController(w, w.decorView).show(WindowInsetsCompat.Type.systemBars())
            }
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }
    LaunchedEffect(landscape) {
        activity?.requestedOrientation =
            if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun toggleBackground(on: Boolean) {
        SessionManager.setBackground(ctx, on)
        if (on && Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    fun minimize() {
        if (SessionManager.backgroundMode) activity?.moveTaskToBack(true)
        else Toast.makeText(ctx, "Aktifkan Background Mode dulu supaya sesi tetap jalan.", Toast.LENGTH_LONG).show()
    }

    BackHandler { panelOpen = !panelOpen }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        engine.Render(Modifier.fillMaxSize())
        TouchLayer(engine, enabled = mode != InputMode.GAMEPAD && !editing)

        when (mode) {
            InputMode.GAMEPAD -> GamepadOverlay(engine, scale)
            InputMode.CODING -> CodingBar(engine, scale, Modifier.align(Alignment.BottomCenter))
            InputMode.CUSTOM -> if (!editing) CustomOverlay(engine, custom, scale)
            InputMode.MOUSE -> Column(
                Modifier.align(Alignment.CenterStart).padding(start = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HoldKey("▲", Modifier.size(40.dp), CircleShape) { if (it) engine.sendWheel(120) }
                HoldKey("▼", Modifier.size(40.dp), CircleShape) { if (it) engine.sendWheel(-120) }
            }
        }
        if (keyboardOn) SystemKeyboardInput(engine)

        // Status kiri-atas
        val dot = when (engine.state) {
            RdpState.CONNECTED -> Fx.Green
            RdpState.CONNECTING -> Color(0xFFFFC857)
            else -> Fx.Red
        }
        Row(
            Modifier.align(Alignment.TopStart).padding(10.dp)
                .background(Color(0xAA000000), RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(8.dp).background(dot, CircleShape))
            Spacer(Modifier.width(6.dp))
            Text(
                buildString {
                    append(when (engine.state) {
                        RdpState.CONNECTED -> "Connected"
                        RdpState.CONNECTING -> "Connecting…"
                        RdpState.FAILED -> "Gagal"
                        RdpState.IDLE -> "Idle"
                    })
                    profile?.let { append(" • ${it.name}") }
                    if (engine.fps > 0) append(" • ${engine.fps} FPS")
                    if (engine.pingMs >= 0) append(" • ${engine.pingMs}ms")
                    if (engine.isPreview) append(" • PRATINJAU")
                },
                color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold
            )
        }

        // Handle + side menu di sisi kanan (disembunyikan saat mengedit layout)
        if (!editing) Row(Modifier.align(Alignment.CenterEnd), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.width(26.dp).height(76.dp)
                    .background(Color(0xCC0B121C), RoundedCornerShape(topStart = 14.dp, bottomStart = 14.dp))
                    .border(1.dp, Fx.Neon.copy(alpha = 0.6f), RoundedCornerShape(topStart = 14.dp, bottomStart = 14.dp))
                    .clickable { panelOpen = !panelOpen },
                contentAlignment = Alignment.Center
            ) {
                Icon(if (panelOpen) Icons.Default.ChevronRight else Icons.Default.ChevronLeft, "Menu", tint = Fx.Neon)
            }
            AnimatedVisibility(
                visible = panelOpen,
                enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
                exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut()
            ) {
                SidePanel(
                    engine = engine, profile = profile, mode = mode, keyboardOn = keyboardOn,
                    scale = scale, landscape = landscape,
                    onMode = { mode = it; panelOpen = false },
                    onKeyboard = { keyboardOn = !keyboardOn; panelOpen = false },
                    onScale = { scale = it },
                    onRotate = { landscape = !landscape },
                    onBackground = ::toggleBackground,
                    onMinimize = ::minimize,
                    onDisconnect = { confirmDisconnect = true },
                    onEditLayout = { mode = InputMode.CUSTOM; editing = true; panelOpen = false }
                )
            }
        }

        if (editing) {
            LayoutEditor(
                initial = custom, scale = scale,
                onCancel = { editing = false },
                onSave = { list ->
                    LayoutStore.save(ctx, list)
                    custom = list
                    editing = false
                    mode = InputMode.CUSTOM
                }
            )
        }

        when (engine.state) {
            RdpState.CONNECTING -> Column(
                Modifier.align(Alignment.Center).background(Color(0xCC000000), RoundedCornerShape(16.dp)).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(color = Fx.Neon)
                Spacer(Modifier.height(10.dp))
                Text(engine.message, color = Color.White, fontSize = 12.sp)
            }
            RdpState.FAILED -> Column(
                Modifier.align(Alignment.Center).background(Color(0xE6000000), RoundedCornerShape(16.dp)).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Koneksi gagal", color = Fx.Red, fontWeight = FontWeight.Bold)
                Text(engine.message, color = Color.White, fontSize = 12.sp)
                TextButton({ SessionManager.disconnect(ctx) }) { Text("Kembali", color = Fx.Neon) }
            }
            else -> {}
        }
    }

    if (confirmDisconnect) {
        AlertDialog(
            onDismissRequest = { confirmDisconnect = false },
            containerColor = Fx.Panel,
            title = { Text("Putuskan koneksi?", color = Color.White) },
            text = { Text("Sesi dengan ${profile?.name ?: "PC"} akan ditutup.", color = Fx.Muted) },
            confirmButton = {
                TextButton({ confirmDisconnect = false; SessionManager.disconnect(ctx) }) { Text("Disconnect", color = Fx.Red) }
            },
            dismissButton = { TextButton({ confirmDisconnect = false }) { Text("Batal", color = Fx.Muted) } }
        )
    }
}

// ───────────────────────── Sentuhan = pointer ─────────────────────────

@Composable
private fun TouchLayer(engine: RdpEngine, enabled: Boolean) {
    var area by remember { mutableStateOf(IntSize.Zero) }
    fun move(o: Offset) {
        engine.sendMouseMove(
            (o.x / area.width.coerceAtLeast(1)).coerceIn(0f, 1f),
            (o.y / area.height.coerceAtLeast(1)).coerceIn(0f, 1f)
        )
    }
    fun click(button: Int, times: Int = 1) {
        repeat(times) { engine.sendMouseButton(button, true); engine.sendMouseButton(button, false) }
    }
    Box(
        Modifier.fillMaxSize().onSizeChanged { area = it }
            .pointerInput(enabled) {
                if (enabled) detectTapGestures(
                    onTap = { move(it); click(0) },
                    onDoubleTap = { move(it); click(0, 2) },
                    onLongPress = { move(it); click(1) }
                )
            }
            .pointerInput(enabled) {
                if (enabled) detectDragGestures(onDrag = { change, _ -> change.consume(); move(change.position) })
            }
    )
}

// ───────────────────────── Tombol tahan (gamepad & keys) ─────────────────────────

/** Tampilan tombol (tanpa gesture). Dipakai juga oleh editor layout. */
@Composable
fun KeyFace(
    label: String, modifier: Modifier, shape: Shape,
    fontSize: TextUnit = 14.sp, pressed: Boolean = false
) {
    Box(
        modifier
            .background(if (pressed) Fx.Neon.copy(alpha = 0.6f) else Color(0xB0081826), shape)
            .border(1.5.dp, Fx.Neon, shape)
            .padding(horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = fontSize, maxLines = 1) }
}

/** Tombol yang aktif selama ditekan: onPress(true) saat turun, onPress(false) saat dilepas. */
@Composable
fun HoldKey(
    label: String, modifier: Modifier, shape: Shape,
    fontSize: TextUnit = 14.sp, onPress: (Boolean) -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    val cb by rememberUpdatedState(onPress)
    KeyFace(
        label,
        modifier.pointerInput(Unit) {
            detectTapGestures(onPress = {
                pressed = true
                cb(true)
                try { tryAwaitRelease() } finally { pressed = false; cb(false) }
            })
        },
        shape, fontSize, pressed
    )
}

// ───────────────────────── Gamepad ─────────────────────────

@Composable
private fun GamepadOverlay(engine: RdpEngine, scale: Float) {
    val btn = (54 * scale).dp
    val round = RoundedCornerShape(14.dp)
    fun pad(b: PadButton): (Boolean) -> Unit = { engine.sendGamepad(b, it) }

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.align(Alignment.BottomStart).padding(start = 28.dp, bottom = 28.dp).size(btn * 3)) {
            HoldKey("▲", Modifier.align(Alignment.TopCenter).size(btn), round, onPress = pad(PadButton.UP))
            HoldKey("◀", Modifier.align(Alignment.CenterStart).size(btn), round, onPress = pad(PadButton.LEFT))
            HoldKey("▶", Modifier.align(Alignment.CenterEnd).size(btn), round, onPress = pad(PadButton.RIGHT))
            HoldKey("▼", Modifier.align(Alignment.BottomCenter).size(btn), round, onPress = pad(PadButton.DOWN))
        }
        Box(Modifier.align(Alignment.BottomEnd).padding(end = 44.dp, bottom = 28.dp).size(btn * 3)) {
            HoldKey("Y", Modifier.align(Alignment.TopCenter).size(btn), CircleShape, onPress = pad(PadButton.Y))
            HoldKey("X", Modifier.align(Alignment.CenterStart).size(btn), CircleShape, onPress = pad(PadButton.X))
            HoldKey("B", Modifier.align(Alignment.CenterEnd).size(btn), CircleShape, onPress = pad(PadButton.B))
            HoldKey("A", Modifier.align(Alignment.BottomCenter).size(btn), CircleShape, onPress = pad(PadButton.A))
        }
        Row(
            Modifier.align(Alignment.TopStart).padding(start = 28.dp, top = 56.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HoldKey("L2", Modifier.size(btn * 1.2f, btn * 0.8f), round, onPress = pad(PadButton.L2))
            HoldKey("L1", Modifier.size(btn * 1.2f, btn * 0.8f), round, onPress = pad(PadButton.L1))
        }
        Row(
            Modifier.align(Alignment.TopEnd).padding(end = 44.dp, top = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HoldKey("R1", Modifier.size(btn * 1.2f, btn * 0.8f), round, onPress = pad(PadButton.R1))
            HoldKey("R2", Modifier.size(btn * 1.2f, btn * 0.8f), round, onPress = pad(PadButton.R2))
        }
        Row(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            HoldKey("SELECT", Modifier.size(btn * 1.5f, btn * 0.6f), round, 11.sp, pad(PadButton.SELECT))
            HoldKey("START", Modifier.size(btn * 1.5f, btn * 0.6f), round, 11.sp, pad(PadButton.START))
        }
    }
}

// ───────────────────────── Coding keys ─────────────────────────

@Composable
private fun CodingBar(engine: RdpEngine, scale: Float, modifier: Modifier) {
    val held = remember { mutableStateListOf<Int>() }
    DisposableEffect(Unit) { onDispose { held.forEach { engine.sendScanCode(it, false) } } }
    var expanded by remember { mutableStateOf(true) }
    val h = (38 * scale).dp
    val fs = (12 * scale).sp
    val shape = RoundedCornerShape(10.dp)

    @Composable
    fun Key(label: String, scan: Int) =
        HoldKey(label, Modifier.height(h).widthIn(min = h * 1.2f), shape, fs) { engine.sendScanCode(scan, it) }

    @Composable
    fun Sticky(label: String, scan: Int) {
        val on = scan in held
        Box(
            Modifier.height(h).widthIn(min = h * 1.4f)
                .background(if (on) Fx.Neon else Color(0xB0081826), shape)
                .border(1.5.dp, Fx.Neon, shape)
                .clickable {
                    if (on) { held.remove(scan); engine.sendScanCode(scan, false) }
                    else { held.add(scan); engine.sendScanCode(scan, true) }
                }.padding(horizontal = 6.dp),
            contentAlignment = Alignment.Center
        ) { Text(label, color = if (on) Fx.Bg else Color.White, fontWeight = FontWeight.Bold, fontSize = fs) }
    }

    @Composable
    fun Chord(label: String, vararg codes: Int) {
        Box(
            Modifier.height(h).widthIn(min = h * 1.4f)
                .background(Color(0xB02A1250), shape).border(1.5.dp, Fx.Violet, shape)
                .clickable {
                    codes.forEach { engine.sendScanCode(it, true) }
                    codes.reversed().forEach { engine.sendScanCode(it, false) }
                }.padding(horizontal = 8.dp),
            contentAlignment = Alignment.Center
        ) { Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = fs) }
    }

    @Composable
    fun KeyRow(content: @Composable RowScope.() -> Unit) = Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically, content = content
    )

    Column(
        modifier.fillMaxWidth().background(Color(0xE60A121C)).padding(horizontal = 8.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Row(Modifier.fillMaxWidth().clickable { expanded = !expanded }, verticalAlignment = Alignment.CenterVertically) {
            Text("Coding keys", color = Fx.Neon, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(if (expanded) "▾ sembunyikan" else "▴ tampilkan", color = Fx.Muted, fontSize = 11.sp)
        }
        if (expanded) {
            KeyRow {
                Chord("Win", Sc.WIN); Chord("Alt+Tab", Sc.ALT, Sc.TAB)
                Chord("Ctrl+C", Sc.CTRL, Sc.C); Chord("Ctrl+V", Sc.CTRL, Sc.V)
                Chord("Ctrl+Z", Sc.CTRL, Sc.Z); Chord("Ctrl+S", Sc.CTRL, Sc.S)
                Chord("Ctrl+Alt+End", Sc.CTRL, Sc.ALT, Sc.END)
            }
            KeyRow {
                Key("ESC", Sc.ESC); Key("TAB", Sc.TAB)
                Sticky("CTRL", Sc.CTRL); Sticky("ALT", Sc.ALT); Sticky("SHIFT", Sc.SHIFT)
                Key("⌫", Sc.BKSP); Key("ENTER", Sc.ENTER)
                Key("←", Sc.LEFT); Key("↑", Sc.UP); Key("↓", Sc.DOWN); Key("→", Sc.RIGHT)
            }
            KeyRow {
                for (n in 1..12) Key("F$n", Sc.f(n))
                Key("HOME", Sc.HOME); Key("END", Sc.END); Key("PGUP", Sc.PGUP); Key("PGDN", Sc.PGDN)
                Key("INS", Sc.INS); Key("DEL", Sc.DEL)
            }
        }
    }
}

// ───────────────────────── Keyboard HP ─────────────────────────

/**
 * Field tak terlihat yang menangkap input keyboard Android lalu meneruskannya ke engine.
 * Isinya selalu di-reset ke satu spasi "sentinel" supaya tombol hapus tetap terdeteksi.
 */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
private fun SystemKeyboardInput(engine: RdpEngine) {
    val focus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    var tf by remember { mutableStateOf(TextFieldValue(" ", TextRange(1))) }
    LaunchedEffect(Unit) { focus.requestFocus(); keyboard?.show() }
    DisposableEffect(Unit) { onDispose { keyboard?.hide() } }
    BasicTextField(
        value = tf,
        onValueChange = { v ->
            val t = v.text
            when {
                t.isEmpty() -> { engine.sendScanCode(Sc.BKSP, true); engine.sendScanCode(Sc.BKSP, false) }
                t.length > 1 -> engine.sendUnicodeText(t.substring(1))
            }
            tf = TextFieldValue(" ", TextRange(1))
        },
        modifier = Modifier.size(1.dp).alpha(0f).focusRequester(focus),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Send, autoCorrectEnabled = false),
        keyboardActions = KeyboardActions(onSend = {
            engine.sendScanCode(Sc.ENTER, true); engine.sendScanCode(Sc.ENTER, false)
        })
    )
}

// ───────────────────────── Side menu ─────────────────────────

@Composable
private fun SidePanel(
    engine: RdpEngine, profile: RdpProfile?, mode: InputMode, keyboardOn: Boolean,
    scale: Float, landscape: Boolean,
    onMode: (InputMode) -> Unit, onKeyboard: () -> Unit, onScale: (Float) -> Unit,
    onRotate: () -> Unit, onBackground: (Boolean) -> Unit, onMinimize: () -> Unit, onDisconnect: () -> Unit,
    onEditLayout: () -> Unit
) {
    val w = (LocalConfiguration.current.screenWidthDp * 0.4f).coerceIn(210f, 290f).dp
    val shape = RoundedCornerShape(topStart = 22.dp, bottomStart = 22.dp)
    Column(
        Modifier.width(w).fillMaxHeight().background(Color(0xF2070B12), shape).border(1.dp, Fx.Line, shape)
            .verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().neonPanel(RoundedCornerShape(16.dp), accent = Fx.Green).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(profile?.name ?: "PC", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
                Text("${profile?.host}:${profile?.port}", color = Fx.Muted, fontSize = 11.sp, maxLines = 1)
            }
            SignalBars(engine.pingMs)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ToggleTile("Mouse", Icons.Default.Mouse, mode == InputMode.MOUSE, Modifier.weight(1f)) { onMode(InputMode.MOUSE) }
            ToggleTile("Keyboard", Icons.Default.Keyboard, keyboardOn, Modifier.weight(1f), onClick = onKeyboard)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ToggleTile("Gamepad", Icons.Default.SportsEsports, mode == InputMode.GAMEPAD, Modifier.weight(1f)) { onMode(InputMode.GAMEPAD) }
            ToggleTile("Coding", Icons.Default.Code, mode == InputMode.CODING, Modifier.weight(1f)) { onMode(InputMode.CODING) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ToggleTile("Custom", Icons.Default.Tune, mode == InputMode.CUSTOM, Modifier.weight(1f)) { onMode(InputMode.CUSTOM) }
            ToggleTile("Edit tombol", Icons.Default.Edit, false, Modifier.weight(1f), onClick = onEditLayout)
        }

        Column(Modifier.fillMaxWidth().neonPanel(RoundedCornerShape(14.dp)).padding(10.dp)) {
            Row {
                Text("Ukuran tombol", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Text("${(scale * 100).toInt()}%", color = Fx.Neon, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = scale, onValueChange = onScale, valueRange = 0.7f..1.4f,
                colors = SliderDefaults.colors(thumbColor = Fx.Neon, activeTrackColor = Fx.Neon)
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ToggleTile("Rec", Icons.Default.FiberManualRecord, false, Modifier.weight(1f), enabled = false, sub = "segera") {}
            ToggleTile(
                "Audio", if (SessionManager.audioOn) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                SessionManager.audioOn, Modifier.weight(1f)
            ) { SessionManager.audioOn = !SessionManager.audioOn; engine.setAudio(SessionManager.audioOn) }
            ToggleTile(
                "Mic", if (SessionManager.micOn) Icons.Default.Mic else Icons.Default.MicOff,
                SessionManager.micOn, Modifier.weight(1f)
            ) { SessionManager.micOn = !SessionManager.micOn; engine.setMic(SessionManager.micOn) }
        }

        Column(
            Modifier.fillMaxWidth().neonPanel(RoundedCornerShape(14.dp), accent = if (SessionManager.backgroundMode) Fx.Green else Fx.Neon).padding(10.dp)
        ) {
            SwitchRow(
                if (SessionManager.backgroundMode) "Background Mode Aktif" else "Background Mode",
                "Sesi tetap berjalan saat aplikasi diminimalkan",
                SessionManager.backgroundMode, onBackground
            )
        }

        ToggleTile(
            if (landscape) "Landscape terkunci" else "Putar layar", Icons.Default.ScreenRotation, landscape,
            Modifier.fillMaxWidth(), onClick = onRotate
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onDisconnect, Modifier.weight(1f).height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A0F14), contentColor = Fx.Red),
                shape = RoundedCornerShape(14.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp)
            ) { Icon(Icons.Default.PowerSettingsNew, null); Text(" Putus", fontSize = 12.sp) }
            Button(
                onMinimize, Modifier.weight(1f).height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Fx.Violet, contentColor = Color.White),
                shape = RoundedCornerShape(14.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp)
            ) { Icon(Icons.Default.Minimize, null); Text(" Minimize", fontSize = 12.sp) }
        }
    }
}

@Composable
private fun ToggleTile(
    label: String, icon: ImageVector, selected: Boolean, modifier: Modifier,
    enabled: Boolean = true, sub: String? = null, onClick: () -> Unit
) {
    val fill = if (selected) Brush.verticalGradient(listOf(Fx.Blue.copy(alpha = 0.55f), Fx.Panel))
    else Brush.verticalGradient(listOf(Fx.PanelHi, Fx.Panel))
    Column(
        modifier.alpha(if (enabled) 1f else 0.45f)
            .neonPanel(RoundedCornerShape(14.dp), accent = if (selected) Fx.Neon else Fx.Line, fill = fill)
            .clickable(enabled = enabled, onClick = onClick).padding(vertical = 10.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = if (selected) Fx.Neon else Color.White)
        Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        if (sub != null) Text(sub, color = Fx.Muted, fontSize = 9.sp)
    }
}
