package com.fryco.remotedesktop

import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class RdpState { IDLE, CONNECTING, CONNECTED, FAILED }

enum class PadButton { UP, DOWN, LEFT, RIGHT, A, B, X, Y, L1, L2, R1, R2, START, SELECT }

class RdpProfile(
    val name: String,
    val host: String,
    val port: Int,
    val username: String,
    val password: String
)

/**
 * Kontrak antara UI dan mesin RDP. UI (SessionScreen) hanya bicara lewat interface ini.
 * Saat FreeRDP terintegrasi, cukup bikin class baru yang mengimplementasikan RdpEngine
 * lalu ganti RdpEngines.create(). UI tidak perlu diubah.
 *
 * Scan code = PS/2 set 1. Tombol extended (panah, Home, End, Del, Win, dst.) dikodekan
 * 0xE000 or kode, jadi mesin harus memecahnya jadi flag extended + kode saat dikirim.
 */
interface RdpEngine {
    val state: RdpState
    val message: String
    /** true = ini mesin pratinjau UI, BUKAN koneksi RDP sungguhan. */
    val isPreview: Boolean
    /** <= 0 berarti belum diketahui. */
    val fps: Int
    val pingMs: Int
    /** Teks debug input terakhir (hanya diisi mesin pratinjau). */
    val lastInput: String

    fun connect(profile: RdpProfile)
    fun disconnect()

    fun sendUnicodeText(text: String)
    fun sendScanCode(scanCode: Int, down: Boolean)
    /** x,y ternormalisasi 0..1 terhadap area tampilan remote. */
    fun sendMouseMove(x: Float, y: Float)
    /** 0 = kiri, 1 = kanan, 2 = tengah. */
    fun sendMouseButton(button: Int, down: Boolean)
    fun sendWheel(delta: Int)
    fun sendGamepad(button: PadButton, down: Boolean)

    fun setAudio(on: Boolean)
    fun setMic(on: Boolean)

    /** Menggambar layar remote. Mesin asli akan memakai AndroidView { SurfaceView }. */
    @Composable
    fun Render(modifier: Modifier)
}

object RdpEngines {
    /** Ubah ke true setelah FreeRDP terpasang. */
    const val IS_REAL = false
    fun create(): RdpEngine = PreviewRdpEngine()
}

/**
 * Mesin pratinjau: mensimulasikan state saja supaya seluruh UI sesi (side menu, gamepad,
 * coding keys, background mode) bisa dicoba. Tidak ada koneksi jaringan dan tidak ada input
 * yang dikirim ke PC.
 */
class PreviewRdpEngine : RdpEngine {
    private val handler = Handler(Looper.getMainLooper())

    override var state by mutableStateOf(RdpState.IDLE)
        private set
    override var message by mutableStateOf("")
        private set
    override val isPreview = true
    override var fps by mutableIntStateOf(0)
        private set
    override var pingMs by mutableIntStateOf(-1)
        private set
    override var lastInput by mutableStateOf("")
        private set

    override fun connect(profile: RdpProfile) {
        state = RdpState.CONNECTING
        message = "Menghubungkan ke ${profile.host}:${profile.port}…"
        handler.postDelayed({
            state = RdpState.CONNECTED
            message = "Mode pratinjau UI"
        }, 900)
    }

    override fun disconnect() {
        handler.removeCallbacksAndMessages(null)
        state = RdpState.IDLE
    }

    override fun sendUnicodeText(text: String) { lastInput = "Teks: $text" }
    override fun sendScanCode(scanCode: Int, down: Boolean) {
        lastInput = "Key 0x${scanCode.toString(16).uppercase()} ${if (down) "↓" else "↑"}"
    }
    override fun sendMouseMove(x: Float, y: Float) {
        lastInput = "Mouse ${(x * 100).toInt()}%, ${(y * 100).toInt()}%"
    }
    override fun sendMouseButton(button: Int, down: Boolean) {
        lastInput = "Klik ${listOf("kiri", "kanan", "tengah").getOrElse(button) { "?" }} ${if (down) "↓" else "↑"}"
    }
    override fun sendWheel(delta: Int) { lastInput = "Scroll $delta" }
    override fun sendGamepad(button: PadButton, down: Boolean) {
        lastInput = "Gamepad ${button.name} ${if (down) "↓" else "↑"}"
    }
    override fun setAudio(on: Boolean) {}
    override fun setMic(on: Boolean) {}

    @Composable
    override fun Render(modifier: Modifier) {
        Box(
            modifier.background(Brush.linearGradient(listOf(Color(0xFF0A2A6B), Color(0xFF1B5CFF), Color(0xFF0B1E4A)))),
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val s = size.minDimension / 16f
                for (col in 0 until 2) for (row in 0 until 6) {
                    drawRoundRect(
                        Color.White.copy(alpha = 0.18f),
                        topLeft = Offset(s * (0.8f + col * 1.6f), s * (0.8f + row * 1.7f)),
                        size = Size(s, s),
                        cornerRadius = CornerRadius(s * 0.2f)
                    )
                }
                drawRect(Color.Black.copy(alpha = 0.45f), Offset(0f, size.height - s * 1.4f), Size(size.width, s * 1.4f))
            }
            Column(
                Modifier.background(Color(0xCC000000), RoundedCornerShape(14.dp)).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("PRATINJAU UI", color = Fx.Neon, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Text(
                    "Mesin RDP belum terpasang.\nTidak ada koneksi ke PC.",
                    color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center
                )
                if (lastInput.isNotEmpty()) Text(lastInput, color = Fx.Green, fontSize = 11.sp)
            }
        }
    }
}

