package com.fryco.remotedesktop

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        SessionManager.load(applicationContext)
        setContent { FrycoApp() }
    }

    override fun onStop() {
        super.onStop()
        // Tanpa Background Mode, sesi ditutup saat app keluar dari layar.
        // (Rotasi tidak dihitung: configChanges di manifest + isChangingConfigurations.)
        if (!isChangingConfigurations && SessionManager.active && !SessionManager.backgroundMode) {
            SessionManager.disconnect(this)
        }
    }
}

@Composable
fun FrycoApp() {
    val appCtx = LocalContext.current.applicationContext
    val repo = remember { ConnectionRepo(appCtx) }
    val sound = remember { SoundPrefs(appCtx) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Fx.Bg, surface = Fx.Panel, primary = Fx.Neon,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Box(Modifier.fillMaxSize().background(Fx.Bg)) {
            if (SessionManager.active) SessionScreen() else MainShell(repo, sound)
        }
    }
}
