package com.fryco.remotedesktop

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Tambah / edit koneksi.
 * onSave(koneksi, langsungConnect, passwordYangDiketik)
 * Saat edit, password dikosongkan = pertahankan password tersimpan.
 */
@Composable
fun ConnectionEditor(
    existing: SavedConnection?,
    onDismiss: () -> Unit,
    onSave: (SavedConnection, Boolean, String) -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var host by remember { mutableStateOf(existing?.host ?: "") }
    var port by remember { mutableStateOf((existing?.port ?: 3389).toString()) }
    var user by remember { mutableStateOf(existing?.username ?: "") }
    var pass by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(existing?.kind ?: "PC") }
    var savePw by remember { mutableStateOf(existing == null || existing.passwordEnc.isNotEmpty()) }
    var error by remember { mutableStateOf<String?>(null) }

    fun build(connect: Boolean) {
        val h = host.trim()
        val u = user.trim()
        val p = port.toIntOrNull() ?: -1
        when {
            h.isEmpty() -> error = "Alamat PC / IP wajib diisi."
            u.isEmpty() -> error = "Username wajib diisi."
            p !in 1..65535 -> error = "Port harus 1–65535."
            else -> {
                val pwEnc = when {
                    !savePw -> ""
                    pass.isNotEmpty() -> Crypto.encrypt(pass)
                    else -> existing?.passwordEnc ?: ""
                }
                val c = (existing ?: SavedConnection(name = "", host = h, username = u)).copy(
                    name = name.trim().ifEmpty { h }, host = h, port = p, username = u,
                    passwordEnc = pwEnc, kind = kind
                )
                onSave(c, connect, pass)
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Fx.Panel,
        title = { Text(if (existing == null) "Koneksi baru" else "Edit koneksi", color = Color.White) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FrycoField("Nama", name, { name = it }, "PC Gaming")
                FrycoField("Alamat PC / IP", host, { host = it; error = null }, "192.168.1.10")
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FrycoField("Port", port, { port = it.filter(Char::isDigit) }, "3389", KeyboardType.Number, modifier = Modifier.weight(0.8f))
                    FrycoField("Username", user, { user = it; error = null }, "Windows user", modifier = Modifier.weight(1.2f))
                }
                FrycoField(
                    "Password", pass, { pass = it },
                    hint = if (existing?.passwordEnc?.isNotEmpty() == true) "Kosongkan = pakai yang tersimpan" else "Password akun Windows",
                    password = true
                )
                SwitchRow("Simpan password", "Terenkripsi di HP, tidak perlu login ulang", savePw) { savePw = it }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("PC" to "PC", "LAPTOP" to "Laptop").forEach { (k, label) ->
                        FilterChip(
                            selected = kind == k, onClick = { kind = k }, label = { Text(label, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Fx.Neon, selectedLabelColor = Fx.Bg, labelColor = Color.White
                            )
                        )
                    }
                }
                error?.let { Text(it, color = Fx.Red, fontSize = 12.sp) }
                Text(
                    "Gunakan hanya PC milik sendiri / yang kamu punya izinnya. Dari luar WiFi, sambungkan lewat VPN, bukan port-forward 3389.",
                    color = Fx.Muted, fontSize = 11.sp
                )
            }
        },
        confirmButton = {
            Row {
                TextButton({ build(false) }) { Text("Simpan", color = Fx.Muted) }
                TextButton({ build(true) }) { Text("Simpan & Connect", color = Fx.Neon) }
            }
        },
        dismissButton = { TextButton(onDismiss) { Text("Batal", color = Fx.Muted) } }
    )
}

@Composable
fun PasswordPrompt(c: SavedConnection, onDismiss: () -> Unit, onSubmit: (String) -> Unit) {
    var pw by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Fx.Panel,
        title = { Text("Password untuk ${c.name}", color = Color.White) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${c.username}@${c.host}", color = Fx.Muted, fontSize = 12.sp)
                FrycoField("Password", pw, { pw = it }, password = true)
                Text("Password tidak tersimpan untuk koneksi ini. Aktifkan “Simpan password” lewat Edit kalau mau.", color = Fx.Muted, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton({ onSubmit(pw) }, enabled = pw.isNotEmpty()) { Text("Connect", color = Fx.Neon) } },
        dismissButton = { TextButton(onDismiss) { Text("Batal", color = Fx.Muted) } }
    )
}

@Composable
fun PassphraseDialog(
    title: String, note: String, confirmLabel: String,
    onDismiss: () -> Unit, onConfirm: (String) -> Unit
) {
    var pass by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Fx.Panel,
        title = { Text(title, color = Color.White) },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(note, color = Fx.Muted, fontSize = 12.sp)
                FrycoField("Passphrase", pass, { pass = it }, password = true)
                Text("Passphrase tidak bisa dipulihkan kalau lupa. Catat di tempat aman.", color = Fx.Muted, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton({ onConfirm(pass) }) { Text(confirmLabel, color = Fx.Neon) } },
        dismissButton = { TextButton(onDismiss) { Text("Batal", color = Fx.Muted) } }
    )
}
