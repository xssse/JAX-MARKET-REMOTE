package com.fryco.remotedesktop

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Fx.Neon, unfocusedBorderColor = Color(0xFF344456),
    focusedLabelColor = Fx.Neon, unfocusedLabelColor = Fx.Muted,
    cursorColor = Fx.Neon, focusedTextColor = Color.White, unfocusedTextColor = Color.White
)

@Composable
fun FrycoField(
    label: String, value: String, onValue: (String) -> Unit,
    hint: String = "", type: KeyboardType = KeyboardType.Text,
    password: Boolean = false, modifier: Modifier = Modifier.fillMaxWidth()
) {
    OutlinedTextField(
        value = value, onValueChange = onValue, modifier = modifier,
        label = { Text(label) },
        placeholder = { if (hint.isNotEmpty()) Text(hint, color = Fx.Muted.copy(alpha = 0.6f)) },
        singleLine = true,
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else type),
        colors = fieldColors()
    )
}

@Composable
fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(subtitle, color = Fx.Muted, fontSize = 11.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White, checkedTrackColor = Fx.Green,
                uncheckedThumbColor = Fx.Muted, uncheckedTrackColor = Color(0xFF1B2636)
            )
        )
    }
}

/** 4 batang sinyal. [ping] < 0 = belum diketahui, semua batang abu-abu. */
@Composable
fun SignalBars(ping: Int) {
    val level = when {
        ping < 0 -> 0
        ping < 40 -> 4
        ping < 80 -> 3
        ping < 150 -> 2
        else -> 1
    }
    Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
        for (i in 1..4) {
            androidx.compose.foundation.layout.Box(
                Modifier.width(5.dp).height((6 + i * 5).dp)
                    .background(if (i <= level) Fx.Green else Color(0xFF2A3647), RoundedCornerShape(2.dp))
            )
        }
    }
}
