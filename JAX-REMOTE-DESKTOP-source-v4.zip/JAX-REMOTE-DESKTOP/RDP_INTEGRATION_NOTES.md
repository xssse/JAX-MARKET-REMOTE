# RDP integration notes

## Upstream engine
Start from the official FreeRDP Android Studio project rather than inventing JNI
bindings. Review its current Java/JNI API before writing an adapter.

Upstream source:
https://github.com/FreeRDP/FreeRDP/tree/master/client/Android/Studio

## Adapter contract to implement
Create an app-owned interface after inspecting the upstream APIs:

- connect(host, port, username, credential, security settings)
- disconnect()
- attachSurface(surface)
- sendUnicodeText(text)
- sendScanCode(scanCode, isDown)
- sendMouseMove(x, y)
- sendMouseButton(button, isDown)
- sendWheel(delta)
- connectionState callbacks

Do not assume these names exist in FreeRDP; they are the app-level contract only.
Map each method to the actual upstream API/JNI functions after source inspection.

## Input modes
Normal: relative/absolute pointer and Android keyboard.
Coding: scan-code keys, modifiers, F1-F12, navigation keys and shortcut chords.
Game: virtual controller layout and Bluetooth/USB controller events. Translate only
controls supported by the remote application and RDP input stack; test per game.

## Recording
Implement Android MediaProjection with explicit user consent and a foreground
service declared with foregroundServiceType="mediaProjection". Android 14+ requires
the matching foreground-service permission and correct service setup. Record only
with visible consent and an obvious stop control.
