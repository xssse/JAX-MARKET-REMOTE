# JAX REMOTE DESKTOP — Android project scaffold

Status v1.1.0: **UI + penyimpanan koneksi + Background Mode sudah jadi; mesin RDP sungguhan belum terpasang.**

Sudah berfungsi (tidak butuh FreeRDP):
- Beranda sesuai desain: hero, kartu status, daftar *Saved Connections* (play / edit / hapus), bottom nav.
- Simpan koneksi (nama, IP, port, username, password opsional). Password dienkripsi AES-GCM
  dengan kunci Android Keystore. Titik hijau = host:port bisa dijangkau (cek TCP singkat).
- Backup / Restore daftar koneksi ke file JSON (SAF). Dengan passphrase: password ikut
  terenkripsi (PBKDF2 + AES-GCM) sehingga bisa dipindah ke HP lain. Tanpa passphrase: tanpa password.
- Layar sesi full-screen dengan side menu di kanan: Mouse / Keyboard / Gamepad / Coding,
  slider ukuran tombol, Audio / Mic (status), Putar layar, Background Mode, Disconnect, Minimize.
- Background Mode: foreground service + notifikasi (ada tombol Disconnect). Tanpa Background Mode,
  sesi ditutup saat app keluar dari layar.

Belum berfungsi — **mesin RDP**: yang aktif sekarang `PreviewRdpEngine` (simulasi state saja).
Layar sesi diberi label "PRATINJAU". Tidak ada koneksi jaringan ke PC dan input tidak dikirim.
Tombol Rec masih nonaktif. Lihat `RDP_INTEGRATION_NOTES.md` untuk langkah memasang FreeRDP:
cukup implementasikan interface `RdpEngine` (Rdp.kt), isi `Render()` dengan SurfaceView,
lalu ubah `RdpEngines.create()` dan `IS_REAL = true`. UI tidak perlu diubah.

## Layout tombol custom (v1.2.0)
Side menu sesi → **Custom** (pakai layout tersimpan) atau **Edit tombol** (masuk editor).
Di editor, toolbar ada di samping layar: Batal, Mouse, Keyboard, D-pad, ukuran −/+, Hapus, Simpan, Bantuan.
- Tombol bisa keyboard apa saja (huruf, angka, F1–F12, Shift/Ctrl/Alt, panah…), tombol mouse
  (kiri/kanan/tengah), atau cluster D-pad (WASD / panah).
- Seret untuk memindah, tarik titik biru di pojok untuk ukuran. Posisi disimpan relatif ke layar,
  jadi tetap pas saat HP diputar.
- Satu layout custom per perangkat (disimpan di SharedPreferences `jax_layout`).
- Touch layar tetap jadi pointer di mode Custom, jadi cocok untuk game yang butuh mouse.

## Catatan nama
Nama tampilan: **JAX REMOTE DESKTOP**. Package/applicationId masih `com.fryco.remotedesktop`
supaya tidak jadi aplikasi baru; ganti lewat refactor Android Studio kalau memang mau.

## Build
1. Install Android Studio versi stabil di Windows.
2. Buka folder `JAX-REMOTE-DESKTOP`.
3. Install Android SDK Platform 35 dan JDK 17 jika diminta.
4. Tunggu Gradle Sync.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Integrasi RDP sungguhan (wajib sebelum rilis)
Gunakan source Android resmi FreeRDP:
https://github.com/FreeRDP/FreeRDP/tree/master/client/Android

Dokumen build:
https://github.com/FreeRDP/FreeRDP/blob/master/docs/README.android

FreeRDP Android terdiri dari Java UI, library native, dan JNI. Integrasi bukan
sekadar menambahkan dependency Maven. Porting perlu menyatukan lifecycle sesi,
surface/video rendering, input pointer/keyboard, autentikasi, sertifikat TLS,
dan callback status. Pertahankan lisensi dan pemberitahuan lisensi upstream.

## Fitur yang belum aktif
- Koneksi RDP native dan rendering desktop (butuh FreeRDP).
- Pengiriman input mouse / keyboard / gamepad ke PC (tombolnya sudah ada, adapter belum).
- Audio & Mic dari/ke PC (toggle sudah ada, channel RDP belum).
- Screen recording MP4 via MediaProjection + foreground service.

## Catatan host Windows
Remote Desktop bawaan Windows sebagai host memerlukan edisi Pro, Enterprise,
atau Education. Windows Home tidak menerima koneksi RDP masuk dengan fitur
bawaan Microsoft. Periksa Settings > System > About > Windows specifications > Edition.

Jangan membuka port RDP langsung ke internet. Untuk akses luar jaringan, gunakan
VPN tepercaya atau jaringan privat yang dikonfigurasi dengan benar. Jangan simpan
password sebagai teks biasa; gunakan Android Keystore-backed encryption.

## Pengujian yang diperlukan
1. Build dan install pada perangkat Android fisik.
2. Uji LAN ke host Windows yang memang mengaktifkan Remote Desktop.
3. Uji sertifikat, autentikasi, reconnect, dan disconnect.
4. Uji mouse, keyboard, gamepad fisik, dan virtual secara terpisah.
5. Uji perekaman, izin, penyimpanan MP4, dan penghentian service.


## Digital System startup sound
An original synthesized startup chime is included at
`app/src/main/res/raw/fryco_digital_system.wav`. It plays when the user presses
CONNECT with the required host and username fields filled. Default volume is
50%; the startup sound toggle is enabled by default. The sound is played locally
on the Android phone. It is not streamed to the remote Windows PC.

The Connect action remains a UI placeholder until the FreeRDP engine is integrated;
playing the sound does not mean an RDP session has connected.
