# Tes protokol (JVM biasa, tanpa Android)

Menguji `RdpProbe.java` (handshake X.224/RDP negotiation) lawan server tiruan,
dan `RdpLink.java` (parser alamat, pembuat file .rdp / URI rdp://).

Dari folder `app/src/main/java`:

    mkdir -p /tmp/jax-out
    javac -d /tmp/jax-out com/fryco/remotedesktop/RdpProbe.java com/fryco/remotedesktop/RdpLink.java \
          ../../../../tools/protocol-tests/ProbeTest.java ../../../../tools/protocol-tests/LinkTest.java
    java -cp /tmp/jax-out ProbeTest
    java -cp /tmp/jax-out LinkTest

Catatan: server tiruan dibuat dari spesifikasi MS-RDPBCGR dan capture standar, bukan Windows asli.
