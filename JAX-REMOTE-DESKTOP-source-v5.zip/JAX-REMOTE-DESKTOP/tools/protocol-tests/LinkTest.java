import com.fryco.remotedesktop.RdpLink;
public class LinkTest {
    static int fails=0;
    static void ck(String n, boolean ok){ System.out.println((ok?"PASS ":"FAIL ")+n); if(!ok) fails++; }
    static boolean eq(String in, String host, int port){ RdpLink.Target t=RdpLink.parseTarget(in); return t!=null && t.host.equals(host) && t.port==port; }
    public static void main(String[] a){
        ck("ipv4", eq("192.168.1.10","192.168.1.10",-1));
        ck("ipv4:port", eq("10.0.0.5:3390","10.0.0.5",3390));
        ck("ngrok tunnel", eq("0.tcp.ap.ngrok.io:12345","0.tcp.ap.ngrok.io",12345));
        ck("rdp:// prefix + slash", eq("rdp://my-pc.local:3389/","my-pc.local",3389));
        ck("spasi di pinggir", eq("  host.example.com  ","host.example.com",-1));
        ck("ipv6 bracket+port", eq("[fe80::1]:3389","fe80::1",3389));
        ck("ipv6 polos", eq("fe80::1","fe80::1",-1));
        ck("port 0 ditolak", RdpLink.parseTarget("host:0")==null);
        ck("port 70000 ditolak", RdpLink.parseTarget("host:70000")==null);
        ck("port huruf ditolak", RdpLink.parseTarget("host:abc")==null);
        ck("spasi di tengah ditolak", RdpLink.parseTarget("my host")==null);
        ck("kosong ditolak", RdpLink.parseTarget("   ")==null && RdpLink.parseTarget(null)==null);
        ck("karakter aneh ditolak", RdpLink.parseTarget("host;rm -rf")==null);

        String f = RdpLink.buildRdpFile("0.tcp.ap.ngrok.io",12345,"runneradmin");
        ck("rdp file address", f.startsWith("full address:s:0.tcp.ap.ngrok.io:12345\r\n"));
        ck("rdp file username", f.contains("username:s:runneradmin\r\n"));
        ck("rdp file tanpa password", !f.toLowerCase().contains("password"));
        String evil = RdpLink.buildRdpFile("h",3389,"bob\r\nenablecredsspsupport:i:0\r\nfull address:s:evil.com");
        int lines = evil.split("\r\n").length;
        ck("injeksi baris di username dinetralkan", !evil.contains("\nenablecredsspsupport") && evil.split("\r\n")[1].startsWith("username:s:bob") && evil.chars().filter(c->c=='\n').count()==lines);
        ck("ipv6 di .rdp berkurung", RdpLink.buildRdpFile("fe80::1",3389,"").contains("full address:s:[fe80::1]:3389"));
        String uri = RdpLink.buildRdpUri("pc.local",3389,"DOMAIN\\user name");
        System.out.println("  uri = "+uri);
        ck("uri format", uri.equals("rdp://full%20address=s:pc.local:3389&username=s:DOMAIN%5Cuser%20name"));
        System.out.println(fails==0?"\nALL PASSED":"\nFAILED "+fails); System.exit(fails==0?0:1);
    }
}
