package com.fryco.remotedesktop

import android.content.Context
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class SavedConnection(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val host: String,
    val port: Int = 3389,
    val username: String,
    /** Password terenkripsi Keystore ("" = tidak disimpan). */
    val passwordEnc: String = "",
    /** "PC" atau "LAPTOP" (hanya untuk ikon). */
    val kind: String = "PC",
    val lastUsed: Long = 0L
) {
    /** [pw] = isi field password yang ditulis ke JSON (terenkripsi / plaintext-untuk-backup / kosong). */
    fun toJson(pw: String): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("host", host).put("port", port)
        .put("user", username).put("pw", pw).put("kind", kind).put("last", lastUsed)

    companion object {
        /** Field password dikembalikan apa adanya di [passwordEnc]; pemanggil yang menentukan artinya. */
        fun fromJson(o: JSONObject) = SavedConnection(
            id = o.optString("id").ifEmpty { UUID.randomUUID().toString() },
            name = o.optString("name"),
            host = o.getString("host"),
            port = o.optInt("port", 3389).coerceIn(1, 65535),
            username = o.optString("user"),
            passwordEnc = o.optString("pw"),
            kind = o.optString("kind", "PC"),
            lastUsed = o.optLong("last", 0L)
        )
    }
}

class ImportResult(val added: Int = 0, val updated: Int = 0, val error: String? = null)

class ConnectionRepo(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("fryco_connections", Context.MODE_PRIVATE)
    val items = mutableStateListOf<SavedConnection>()

    init {
        try {
            val arr = JSONArray(prefs.getString("list", "[]"))
            for (i in 0 until arr.length()) items.add(SavedConnection.fromJson(arr.getJSONObject(i)))
        } catch (e: Exception) {
            items.clear()
        }
    }

    private fun persist() {
        val arr = JSONArray()
        items.forEach { arr.put(it.toJson(it.passwordEnc)) }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    fun save(c: SavedConnection) {
        val i = items.indexOfFirst { it.id == c.id }
        if (i >= 0) items[i] = c else items.add(c)
        persist()
    }

    fun delete(id: String) {
        items.removeAll { it.id == id }
        persist()
    }

    fun password(c: SavedConnection): String = Crypto.decrypt(c.passwordEnc)

    /**
     * Backup ke JSON.
     * - [passphrase] kosong  -> tanpa password (aman dibagi, tapi password harus diketik lagi).
     * - [passphrase] terisi  -> semua data + password dienkripsi AES-GCM dengan passphrase itu.
     */
    fun exportJson(passphrase: String): String {
        val root = JSONObject().put("app", "JAX").put("v", 1)
        if (passphrase.isEmpty()) {
            val arr = JSONArray()
            items.forEach { arr.put(it.toJson("")) }
            root.put("encrypted", false).put("items", arr)
        } else {
            val arr = JSONArray()
            items.forEach { arr.put(it.toJson(Crypto.decrypt(it.passwordEnc))) }
            val salt = Crypto.randomBytes(16)
            val enc = Crypto.encryptWith(Crypto.deriveKey(passphrase, salt), arr.toString().toByteArray(Charsets.UTF_8))
            root.put("encrypted", true)
                .put("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                .put("data", Base64.encodeToString(enc, Base64.NO_WRAP))
        }
        return root.toString(2)
    }

    /** true = butuh passphrase, false = tidak, null = bukan file backup JAX. */
    fun backupNeedsPassphrase(text: String): Boolean? = try {
        val root = JSONObject(text)
        if (root.optString("app") !in listOf("JAX", "FRYCO")) null else root.optBoolean("encrypted", false)
    } catch (e: Exception) {
        null
    }

    fun importJson(text: String, passphrase: String): ImportResult {
        try {
            val root = JSONObject(text)
            if (root.optString("app") !in listOf("JAX", "FRYCO")) return ImportResult(error = "Bukan file backup JAX.")
            val encrypted = root.optBoolean("encrypted", false)
            val arr: JSONArray
            if (encrypted) {
                if (passphrase.isEmpty()) return ImportResult(error = "Passphrase dibutuhkan.")
                val salt = Base64.decode(root.getString("salt"), Base64.NO_WRAP)
                val raw = Base64.decode(root.getString("data"), Base64.NO_WRAP)
                val plain = try {
                    Crypto.decryptWith(Crypto.deriveKey(passphrase, salt), raw)
                } catch (e: Exception) {
                    return ImportResult(error = "Passphrase salah.")
                }
                arr = JSONArray(String(plain, Charsets.UTF_8))
            } else {
                arr = root.getJSONArray("items")
            }
            var added = 0
            var updated = 0
            for (i in 0 until arr.length()) {
                val c = SavedConnection.fromJson(arr.getJSONObject(i))
                val idx = items.indexOfFirst { it.id == c.id }
                val pwEnc = when {
                    encrypted -> Crypto.encrypt(c.passwordEnc) // di file ini field "pw" = plaintext
                    idx >= 0 -> items[idx].passwordEnc          // backup tanpa password: jangan hapus yang sudah ada
                    else -> ""
                }
                val fixed = c.copy(passwordEnc = pwEnc)
                if (idx >= 0) { items[idx] = fixed; updated++ } else { items.add(fixed); added++ }
            }
            persist()
            return ImportResult(added, updated)
        } catch (e: Exception) {
            return ImportResult(error = "File backup tidak valid.")
        }
    }
}

/** Pengaturan suara — key SharedPreferences sama seperti versi lama, jadi setelan user tetap terbawa. */
class SoundPrefs(private val ctx: Context) {
    private val p = ctx.getSharedPreferences("fryco_sound_settings", Context.MODE_PRIVATE)
    var startup by mutableStateOf(p.getBoolean("startup", true))
    var connection by mutableStateOf(p.getBoolean("connection", true))
    var disconnect by mutableStateOf(p.getBoolean("disconnect", true))
    var muteAll by mutableStateOf(p.getBoolean("mute_all", false))
    var volume by mutableFloatStateOf(p.getFloat("volume", 0.5f))

    fun save() {
        p.edit().putBoolean("startup", startup).putBoolean("connection", connection)
            .putBoolean("disconnect", disconnect).putBoolean("mute_all", muteAll)
            .putFloat("volume", volume).apply()
    }

    fun playStartup() {
        if (!startup || muteAll) return
        val player = android.media.MediaPlayer.create(ctx, R.raw.fryco_digital_system) ?: return
        player.setAudioAttributes(
            android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        player.setVolume(volume, volume)
        player.setOnCompletionListener { it.release() }
        player.setOnErrorListener { mp, _, _ -> mp.release(); true }
        player.start()
    }
}
