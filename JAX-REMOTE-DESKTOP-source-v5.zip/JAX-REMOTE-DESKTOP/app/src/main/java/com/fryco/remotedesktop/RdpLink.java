package com.fryco.remotedesktop;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/** Parsing alamat + pembuat file .rdp / URI rdp://. Java murni, dites di JVM. */
public final class RdpLink {
    private RdpLink() {}

    public static final class Target {
        public final String host;
        /** -1 = tidak disebut di input. */
        public final int port;
        Target(String host, int port) { this.host = host; this.port = port; }
    }

    /**
     * Menerima: "192.168.1.10", "pc-saya.local", "0.tcp.ap.ngrok.io:12345", "rdp://host:3390/",
     * "[fe80::1]:3389", "fe80::1". Mengembalikan null kalau tidak valid.
     */
    public static Target parseTarget(String input) {
        if (input == null) return null;
        String s = input.trim();
        for (String scheme : new String[]{"rdp://", "tcp://"}) {
            if (s.toLowerCase().startsWith(scheme)) s = s.substring(scheme.length());
        }
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        if (s.isEmpty()) return null;

        String host;
        int port = -1;
        if (s.startsWith("[")) {                         // IPv6 berkurung
            int close = s.indexOf(']');
            if (close < 0) return null;
            host = s.substring(1, close);
            String rest = s.substring(close + 1);
            if (!rest.isEmpty()) {
                if (!rest.startsWith(":")) return null;
                port = parsePort(rest.substring(1));
                if (port < 0) return null;
            }
        } else {
            int first = s.indexOf(':');
            int last = s.lastIndexOf(':');
            if (first >= 0 && first == last) {           // host:port
                host = s.substring(0, first);
                port = parsePort(s.substring(first + 1));
                if (port < 0) return null;
            } else {
                host = s;                                // nama / IPv4 / IPv6 polos
            }
        }
        if (!validHost(host)) return null;
        return new Target(host, port);
    }

    private static int parsePort(String p) {
        if (p.isEmpty() || p.length() > 5) return -1;
        for (int i = 0; i < p.length(); i++) if (!Character.isDigit(p.charAt(i))) return -1;
        int v = Integer.parseInt(p);
        return (v >= 1 && v <= 65535) ? v : -1;
    }

    private static boolean validHost(String h) {
        if (h.isEmpty() || h.length() > 253) return false;
        for (int i = 0; i < h.length(); i++) {
            char c = h.charAt(i);
            boolean ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')
                    || c == '.' || c == '-' || c == '_' || c == ':' || c == '%';
            if (!ok) return false;
        }
        return true;
    }

    private static String hostForAddress(String host, int port) {
        String h = host.indexOf(':') >= 0 ? "[" + host + "]" : host;
        return h + ":" + port;
    }

    /** Buang CR/LF/NUL dan karakter kontrol supaya input user tidak bisa menyelipkan baris pengaturan lain. */
    static String clean(String v) {
        if (v == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            if (c >= 0x20 && c != 0x7F) b.append(c);
        }
        return b.toString().trim();
    }

    /** Isi file .rdp. Password sengaja TIDAK dimasukkan (format .rdp hanya menerima password terenkripsi DPAPI). */
    public static String buildRdpFile(String host, int port, String username) {
        StringBuilder b = new StringBuilder();
        b.append("full address:s:").append(hostForAddress(clean(host), port)).append("\r\n");
        String u = clean(username);
        if (!u.isEmpty()) b.append("username:s:").append(u).append("\r\n");
        b.append("screen mode id:i:2\r\n");
        b.append("session bpp:i:32\r\n");
        b.append("audiomode:i:0\r\n");
        b.append("redirectclipboard:i:1\r\n");
        b.append("prompt for credentials:i:1\r\n");
        return b.toString();
    }

    /** rdp://full%20address=s:host:port&username=s:user  (dipakai sebagai cadangan jika file .rdp ditolak). */
    public static String buildRdpUri(String host, int port, String username) {
        StringBuilder b = new StringBuilder("rdp://full%20address=s:")
                .append(enc(hostForAddress(clean(host), port)).replace("%3A", ":").replace("%5B", "[").replace("%5D", "]"));
        String u = clean(username);
        if (!u.isEmpty()) b.append("&username=s:").append(enc(u));
        return b.toString();
    }

    private static String enc(String v) {
        try {
            return URLEncoder.encode(v, "UTF-8").replace("+", "%20");
        } catch (UnsupportedEncodingException e) {
            return v;
        }
    }
}
