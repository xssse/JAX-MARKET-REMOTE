package com.fryco.remotedesktop

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * - Password koneksi di HP dienkripsi AES-GCM dengan kunci di Android Keystore
 *   (kunci tidak bisa dipindah ke HP lain).
 * - Untuk backup antar-HP dipakai kunci dari passphrase (PBKDF2 + AES-GCM).
 */
object Crypto {
    private const val ALIAS = "fryco_profile_key"
    private const val GCM_IV_LEN = 12

    private fun keystoreKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(
                ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    /** Enkripsi untuk penyimpanan lokal. String kosong -> string kosong. */
    fun encrypt(plain: String): String {
        if (plain.isEmpty()) return ""
        return try {
            Base64.encodeToString(encryptWith(keystoreKey(), plain.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
        } catch (e: Exception) {
            ""
        }
    }

    /** Gagal dekripsi (kunci hilang/rusak) -> string kosong, UI akan minta password lagi. */
    fun decrypt(enc: String): String {
        if (enc.isEmpty()) return ""
        return try {
            String(decryptWith(keystoreKey(), Base64.decode(enc, Base64.NO_WRAP)), Charsets.UTF_8)
        } catch (e: Exception) {
            ""
        }
    }

    fun encryptWith(key: SecretKey, data: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key)
        return c.iv + c.doFinal(data)
    }

    fun decryptWith(key: SecretKey, raw: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, raw.copyOfRange(0, GCM_IV_LEN)))
        return c.doFinal(raw, GCM_IV_LEN, raw.size - GCM_IV_LEN)
    }

    fun deriveKey(passphrase: String, salt: ByteArray): SecretKey {
        val spec = PBEKeySpec(passphrase.toCharArray(), salt, 120_000, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return SecretKeySpec(bytes, "AES")
    }

    fun randomBytes(n: Int): ByteArray = ByteArray(n).also { SecureRandom().nextBytes(it) }
}
