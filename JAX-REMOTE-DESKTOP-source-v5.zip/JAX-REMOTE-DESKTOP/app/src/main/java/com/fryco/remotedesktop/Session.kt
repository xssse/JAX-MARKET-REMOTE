package com.fryco.remotedesktop

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Pemegang sesi aktif (satu sesi pada satu waktu). Dibaca UI lewat Compose state. */
object SessionManager {
    var engine: RdpEngine? by mutableStateOf(null)
        private set
    var profile: RdpProfile? by mutableStateOf(null)
        private set

    /** Dipertahankan antar-sesi; user yang mengaktifkannya. */
    var backgroundMode by mutableStateOf(false)
        private set
    var audioOn by mutableStateOf(true)
    var micOn by mutableStateOf(false)

    val active: Boolean get() = engine != null

    fun load(ctx: Context) {
        backgroundMode = ctx.getSharedPreferences("fryco_session", Context.MODE_PRIVATE)
            .getBoolean("background", false)
    }

    fun connect(ctx: Context, p: RdpProfile) {
        disconnect(ctx)
        val e = RdpEngines.create()
        engine = e
        profile = p
        e.setAudio(audioOn)
        e.setMic(micOn)
        e.connect(p)
        if (backgroundMode) SessionService.start(ctx, p.name)
    }

    fun disconnect(ctx: Context) {
        engine?.disconnect()
        engine = null
        profile = null
        SessionService.stop(ctx)
    }

    fun setBackground(ctx: Context, on: Boolean) {
        backgroundMode = on
        ctx.getSharedPreferences("fryco_session", Context.MODE_PRIVATE).edit().putBoolean("background", on).apply()
        val p = profile
        if (on && p != null) SessionService.start(ctx, p.name) else SessionService.stop(ctx)
    }
}

/**
 * Foreground service supaya proses tidak dimatikan Android saat app diminimalkan.
 * Service ini TIDAK memegang koneksi; koneksi tetap milik SessionManager/RdpEngine.
 */
class SessionService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_DISCONNECT) {
            SessionManager.disconnect(this)
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, tr("Sesi remote desktop"), NotificationManager.IMPORTANCE_LOW)
        )
        val name = intent?.getStringExtra(EXTRA_NAME) ?: tr("Sesi aktif")
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, SessionService::class.java).setAction(ACTION_DISCONNECT),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notif = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_slideshow) // ganti dengan ikon JAX sendiri
            .setContentTitle("JAX • $name")
            .setContentText(tr("Sesi tetap berjalan di latar belakang"))
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "Disconnect", stop
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
        return START_NOT_STICKY
    }

    companion object {
        private const val CHANNEL = "fryco_session"
        private const val NOTIF_ID = 4101
        private const val EXTRA_NAME = "name"
        private const val ACTION_DISCONNECT = "com.fryco.remotedesktop.DISCONNECT"

        fun start(ctx: Context, name: String) {
            ctx.startForegroundService(Intent(ctx, SessionService::class.java).putExtra(EXTRA_NAME, name))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, SessionService::class.java))
        }
    }
}
