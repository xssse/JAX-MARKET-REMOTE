package com.fryco.remotedesktop

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.math.roundToInt

const val KIND_KEY = "KEY"      // satu tombol keyboard (code = scan code)
const val KIND_MOUSE = "MOUSE"  // tombol mouse (code 0 kiri, 1 kanan, 2 tengah)
const val KIND_PAD = "PAD"      // cluster 4 arah (code 0 = WASD, 1 = panah)

/** x,y = titik tengah tombol, ternormalisasi 0..1 terhadap layar remote. size = pengali ukuran. */
data class CustomButton(
    val id: String = UUID.randomUUID().toString(),
    val kind: String,
    val label: String,
    val code: Int,
    val x: Float,
    val y: Float,
    val size: Float = 1f
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("kind", kind).put("label", label)
        .put("code", code).put("x", x.toDouble()).put("y", y.toDouble()).put("size", size.toDouble())

    companion object {
        fun fromJson(o: JSONObject) = CustomButton(
            id = o.optString("id").ifEmpty { UUID.randomUUID().toString() },
            kind = o.getString("kind"),
            label = o.optString("label"),
            code = o.optInt("code"),
            x = o.optDouble("x", 0.5).toFloat().coerceIn(0f, 1f),
            y = o.optDouble("y", 0.5).toFloat().coerceIn(0f, 1f),
            size = o.optDouble("size", 1.0).toFloat().coerceIn(0.5f, 2.2f)
        )
    }
}

object LayoutStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("jax_layout", Context.MODE_PRIVATE)

    fun load(ctx: Context): List<CustomButton> = try {
        val arr = JSONArray(prefs(ctx).getString("custom", "[]"))
        (0 until arr.length()).map { CustomButton.fromJson(arr.getJSONObject(it)) }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(ctx: Context, list: List<CustomButton>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs(ctx).edit().putString("custom", arr.toString()).apply()
    }
}

/** Daftar tombol yang bisa dipilih di editor. Scan code PS/2 set 1. */
object KeyMap {
    val keys: List<Pair<String, Int>> = buildList {
        "1234567890".forEachIndexed { i, c -> add(c.toString() to 0x02 + i) }
        "QWERTYUIOP".forEachIndexed { i, c -> add(c.toString() to 0x10 + i) }
        "ASDFGHJKL".forEachIndexed { i, c -> add(c.toString() to 0x1E + i) }
        "ZXCVBNM".forEachIndexed { i, c -> add(c.toString() to 0x2C + i) }
        add("SPACE" to 0x39); add("SHIFT" to Sc.SHIFT); add("CTRL" to Sc.CTRL); add("ALT" to Sc.ALT)
        add("TAB" to Sc.TAB); add("ESC" to Sc.ESC); add("ENTER" to Sc.ENTER)
        for (n in 1..12) add("F$n" to Sc.f(n))
        add("↑" to Sc.UP); add("↓" to Sc.DOWN); add("←" to Sc.LEFT); add("→" to Sc.RIGHT)
    }
}

// ───────────────────────── Tampilan satu tombol ─────────────────────────

@Composable
private fun PadCell(label: String, modifier: Modifier, interactive: Boolean, onPress: (Boolean) -> Unit) {
    val fs = if (label.length > 3) 10.sp else 14.sp
    if (interactive) HoldKey(label, modifier, CircleShape, fs, onPress)
    else KeyFace(label, modifier, CircleShape, fs)
}

/** Isi satu tombol custom. Mengisi penuh kotak induknya. interactive=false dipakai di editor. */
@Composable
private fun ButtonBody(b: CustomButton, interactive: Boolean, engine: RdpEngine?) {
    if (b.kind == KIND_PAD) {
        val arrows = b.code == 1
        val codes = if (arrows) listOf(Sc.UP, Sc.LEFT, Sc.DOWN, Sc.RIGHT) else listOf(0x11, 0x1E, 0x1F, 0x20)
        val labels = if (arrows) listOf("▲", "◀", "▼", "▶") else listOf("W", "A", "S", "D")
        val spots = listOf(Alignment.TopCenter, Alignment.CenterStart, Alignment.BottomCenter, Alignment.CenterEnd)
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val cell = maxWidth / 3
            for (i in 0 until 4) {
                PadCell(labels[i], Modifier.align(spots[i]).size(cell), interactive) { down ->
                    engine?.sendScanCode(codes[i], down)
                }
            }
        }
    } else {
        PadCell(b.label, Modifier.fillMaxSize(), interactive) { down ->
            if (b.kind == KIND_MOUSE) engine?.sendMouseButton(b.code, down) else engine?.sendScanCode(b.code, down)
        }
    }
}

private fun footprintFactor(b: CustomButton) = if (b.kind == KIND_PAD) 3f else 1f

// ───────────────────────── Overlay saat bermain ─────────────────────────

@Composable
fun CustomOverlay(engine: RdpEngine, buttons: List<CustomButton>, scale: Float) {
    val density = LocalDensity.current
    val unitPx = with(density) { (54 * scale).dp.toPx() }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val w = constraints.maxWidth.toFloat()
        val h = constraints.maxHeight.toFloat()
        buttons.forEach { b ->
            key(b.id) {
                val fpPx = unitPx * b.size * footprintFactor(b)
                Box(
                    Modifier.offset { IntOffset((b.x * w - fpPx / 2).roundToInt(), (b.y * h - fpPx / 2).roundToInt()) }
                        .size(with(density) { fpPx.toDp() })
                ) { ButtonBody(b, interactive = true, engine = engine) }
            }
        }
        if (buttons.isEmpty()) {
            Text(
                "Belum ada tombol.\nBuka menu samping → Edit tombol.",
                color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.Center).background(Color(0x99000000), RoundedCornerShape(12.dp)).padding(14.dp)
            )
        }
    }
}

// ───────────────────────── Editor layout ─────────────────────────

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LayoutEditor(
    initial: List<CustomButton>, scale: Float,
    onCancel: () -> Unit, onSave: (List<CustomButton>) -> Unit
) {
    val draft = remember { mutableStateListOf<CustomButton>().apply { addAll(initial) } }
    var selected by remember { mutableStateOf<String?>(null) }
    var picker by remember { mutableStateOf("") } // "", "mouse", "key", "pad"
    var help by remember { mutableStateOf(initial.isEmpty()) }
    var w by remember { mutableFloatStateOf(1f) }
    var h by remember { mutableFloatStateOf(1f) }
    val density = LocalDensity.current
    val unitPx = with(density) { (54 * scale).dp.toPx() }

    BackHandler(onBack = onCancel)

    fun update(id: String, f: (CustomButton) -> CustomButton) {
        val i = draft.indexOfFirst { it.id == id }
        if (i >= 0) draft[i] = f(draft[i])
    }
    fun add(kind: String, label: String, code: Int) {
        val n = draft.size
        val b = CustomButton(kind = kind, label = label, code = code, x = 0.25f + (n % 5) * 0.1f, y = 0.3f + ((n / 5) % 4) * 0.13f)
        draft.add(b)
        selected = b.id
        help = false
    }

    Box(
        Modifier.fillMaxSize().background(Color(0x66000000))
            .onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f); h = it.height.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) { detectTapGestures(onTap = { selected = null }) }
    ) {
        draft.forEach { b ->
            key(b.id) {
                val factor = footprintFactor(b)
                val fpPx = unitPx * b.size * factor
                Box(
                    Modifier.offset { IntOffset((b.x * w - fpPx / 2).roundToInt(), (b.y * h - fpPx / 2).roundToInt()) }
                        .size(with(density) { fpPx.toDp() })
                        .pointerInput(b.id) { detectTapGestures(onTap = { selected = b.id }) }
                        .pointerInput(b.id) {
                            detectDragGestures(onDragStart = { selected = b.id }) { change, amt ->
                                change.consume()
                                update(b.id) {
                                    it.copy(
                                        x = (it.x + amt.x / w).coerceIn(0.03f, 0.97f),
                                        y = (it.y + amt.y / h).coerceIn(0.05f, 0.95f)
                                    )
                                }
                            }
                        }
                ) {
                    ButtonBody(b, interactive = false, engine = null)
                    if (selected == b.id) {
                        Box(Modifier.fillMaxSize().border(2.dp, Color.White, RoundedCornerShape(12.dp)))
                        // Titik pojok: tarik untuk mengubah ukuran.
                        Box(
                            Modifier.align(Alignment.BottomEnd).size(24.dp)
                                .background(Fx.Neon, CircleShape).border(2.dp, Color.White, CircleShape)
                                .pointerInput(b.id) {
                                    detectDragGestures { change, amt ->
                                        change.consume()
                                        val d = (amt.x + amt.y) / 2f / (unitPx * factor)
                                        update(b.id) { it.copy(size = (it.size + d).coerceIn(0.5f, 2.2f)) }
                                    }
                                }
                        )
                    }
                }
            }
        }

        // Toolbar di samping layar; lebarnya mengikuti lebar layar supaya nyaman di semua HP.
        val tbW = (LocalConfiguration.current.screenWidthDp * 0.13f).coerceIn(74f, 108f).dp
        Column(
            Modifier.align(Alignment.CenterEnd).padding(end = 6.dp).width(tbW)
                .background(Color(0xF2070B12), RoundedCornerShape(18.dp)).border(1.dp, Fx.Line, RoundedCornerShape(18.dp))
                .verticalScroll(rememberScrollState()).padding(6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ToolItem("Batal", Icons.Default.Close, Fx.Red) { onCancel() }
            ToolItem("Mouse", Icons.Default.Mouse, Fx.Neon) { picker = "mouse" }
            ToolItem("Keyboard", Icons.Default.Keyboard, Fx.Neon) { picker = "key" }
            ToolItem("D-pad", Icons.Default.Gamepad, Fx.Neon) { picker = "pad" }
            val sel = selected
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                ToolIcon(Icons.Default.Remove, sel != null) { sel?.let { id -> update(id) { it.copy(size = (it.size - 0.1f).coerceAtLeast(0.5f)) } } }
                ToolIcon(Icons.Default.Add, sel != null) { sel?.let { id -> update(id) { it.copy(size = (it.size + 0.1f).coerceAtMost(2.2f)) } } }
            }
            Text("ukuran", color = Fx.Muted, fontSize = 9.sp)
            ToolItem("Hapus", Icons.Default.Delete, Fx.Muted, enabled = sel != null) {
                sel?.let { id -> draft.removeAll { it.id == id }; selected = null }
            }
            ToolItem("Simpan", Icons.Default.Check, Fx.Green) { onSave(draft.toList()) }
            ToolItem("Bantuan", Icons.Default.Info, Fx.Muted) { help = !help }
        }

        if (help) {
            Column(
                Modifier.align(Alignment.Center).background(Color(0xE6000000), RoundedCornerShape(16.dp))
                    .clickable { help = false }.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text("Atur tombol", color = Fx.Neon, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("• Tambah tombol dari menu di samping", color = Color.White, fontSize = 12.sp)
                Text("• Seret tombol untuk memindahkan", color = Color.White, fontSize = 12.sp)
                Text("• Tarik titik biru di pojok untuk ukuran", color = Color.White, fontSize = 12.sp)
                Text("• Ketuk tombol untuk memilih, lalu Hapus", color = Color.White, fontSize = 12.sp)
                Text("• Simpan untuk memakai, Batal untuk membuang", color = Color.White, fontSize = 12.sp)
                Text("(ketuk untuk menutup)", color = Fx.Muted, fontSize = 10.sp)
            }
        }
    }

    when (picker) {
        "mouse" -> AlertDialog(
            onDismissRequest = { picker = "" }, containerColor = Fx.Panel,
            title = { Text("Tombol mouse", color = Color.White) },
            text = {
                Column {
                    listOf("Klik kiri" to 0, "Klik kanan" to 1, "Klik tengah" to 2).forEach { (name, code) ->
                        TextButton({ add(KIND_MOUSE, listOf("L", "R", "M")[code], code); picker = "" }) { Text(name, color = Fx.Neon) }
                    }
                }
            },
            confirmButton = {}, dismissButton = { TextButton({ picker = "" }) { Text("Batal", color = Fx.Muted) } }
        )
        "pad" -> AlertDialog(
            onDismissRequest = { picker = "" }, containerColor = Fx.Panel,
            title = { Text("D-pad", color = Color.White) },
            text = {
                Column {
                    TextButton({ add(KIND_PAD, "WASD", 0); picker = "" }) { Text("WASD", color = Fx.Neon) }
                    TextButton({ add(KIND_PAD, "Panah", 1); picker = "" }) { Text("Tombol panah", color = Fx.Neon) }
                }
            },
            confirmButton = {}, dismissButton = { TextButton({ picker = "" }) { Text("Batal", color = Fx.Muted) } }
        )
        "key" -> AlertDialog(
            onDismissRequest = { picker = "" }, containerColor = Fx.Panel,
            title = { Text("Pilih tombol", color = Color.White) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        KeyMap.keys.forEach { (name, code) ->
                            Box(
                                Modifier.background(Color(0xFF0E2238), RoundedCornerShape(10.dp))
                                    .border(1.dp, Fx.Neon.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                                    .clickable { add(KIND_KEY, name, code); picker = "" }
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) { Text(name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                        }
                    }
                }
            },
            confirmButton = {}, dismissButton = { TextButton({ picker = "" }) { Text("Batal", color = Fx.Muted) } }
        )
    }
}

@Composable
private fun ToolItem(label: String, icon: ImageVector, tint: Color, enabled: Boolean = true, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().alpha(if (enabled) 1f else 0.4f)
            .clickable(enabled = enabled, onClick = onClick).padding(vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(22.dp))
        Text(label, color = Color.White, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun ToolIcon(icon: ImageVector, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(32.dp).alpha(if (enabled) 1f else 0.4f)
            .background(Color(0xFF0E2238), CircleShape).border(1.dp, Fx.Neon.copy(alpha = 0.6f), CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = Fx.Neon, modifier = Modifier.size(18.dp)) }
}
