package com.fryco.remotedesktop

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val CONNECTION_KINDS = listOf(
    "PC" to "PC",
    "LAPTOP" to "Laptop",
    "SERVER" to "Server / VPS",
    "GITHUB" to "GitHub / Tunnel"
)

/**
 * Tambah / edit koneksi. Alamat boleh IP, domain, atau alamat tunnel "host:port"
 * (mis. 0.tcp.ap.ngrok.io:12345 dari RDP GitHub Actions).
 * onSave(koneksi, langsungConnect, passwordYangDiketik)
 * Saat edit, password dikosongkan = pertahankan password tersimpan.
 */
@Composable
fun ConnectionEditor(
    existing: SavedConnection?,
    onDismiss: () -> Unit,
    onSave: (SavedConnection, Boolean, String) -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var host by remember { mutableStateOf(existing?.host ?: "") }
    var port by remember { mutableStateOf((existing?.port ?: 3389).toString()) }
    var user by remember { mutableStateOf(existing?.username ?: "") }
    var pass by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(existing?.kind ?: "PC") }
    var savePw by remember { mutableStateOf(existing == null || existing.passwordEnc.isNotEmpty()) }
    var error by remember { mutableStateOf<String?>(null) }

    fun build(connect: Boolean) {
        val t = RdpLink.parseTarget(host)
        val u = user.trim()
        if (t == null) {
            error = tr("Alamat tidak valid. Contoh: 192.168.1.10 atau 0.tcp.ap.ngrok.io:12345")
            return
        }
        val p = if (t.port > 0) t.port else (port.toIntOrNull() ?: -1)
        if (p !in 1..65535) {
            error = tr("Port harus 1–65535.")
            return
        }
        val pwEnc = when {
            !savePw -> ""
            pass.isNotEmpty() -> Crypto.encrypt(pass)
            else -> existing?.passwordEnc ?: ""
        }
        val c = (existing ?: SavedConnection(name = "", host = t.host, username = u)).copy(
            name = name.trim().ifEmpty { t.host }, host = t.host, port = p, username = u,
            passwordEnc = pwEnc, kind = kind
        )
        onSave(c, connect, pass)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Fx.Panel,
        title = { Text(if (existing == null) "Koneksi baru" else "Edit koneksi", color = Color.White) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CONNECTION_KINDS.forEach { (k, label) ->
                        FilterChip(
                            selected = kind == k, onClick = { kind = k }, label = { Text(label, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Fx.Neon, selectedLabelColor = Fx.Bg, labelColor = Color.White
                            )
                        )
                    }
                }
                FrycoField("Nama", name, { name = it }, "PC Gaming")
                FrycoField(
                    "Alamat (IP / domain / tunnel)", host, { host = it; error = null },
                    if (kind == "GITHUB") "0.tcp.ap.ngrok.io:12345" else "192.168.1.10"
                )
                FrycoField("Port", port, { port = it.filter(Char::isDigit) }, "3389", KeyboardType.Number)
                FrycoField("Username", user, { user = it }, "Administrator / DOMAIN\\user")
                FrycoField(
                    "Password", pass, { pass = it },
                    hint = if (existing?.passwordEnc?.isNotEmpty() == true) "Kosongkan = pakai yang tersimpan" else "Password akun Windows",
                    password = true
                )
                SwitchRow("Simpan password", "Terenkripsi di HP, tidak perlu login ulang", savePw) { savePw = it }
                if (kind == "GITHUB") {
                    Text(
                        "Tempel alamat tunnel dari log workflow. Alamat dan password RDP GitHub biasanya berubah tiap sesi; edit koneksi ini kalau berubah.",
                        color = Fx.Muted, fontSize = 11.sp
                    )
                }
                error?.let { Text(it, color = Fx.Red, fontSize = 12.sp) }
                Text(
                    "Gunakan hanya komputer milik sendiri atau yang kamu punya izinnya. Dari luar WiFi, pakai VPN/tunnel, jangan buka port 3389 langsung ke internet.",
                    color = Fx.Muted, fontSize = 11.sp
                )
            }
        },
        confirmButton = {
            Row {
                TextButton({ build(false) }) { Text("Simpan", color = Fx.Muted) }
                TextButton({ build(true) }) { Text("Simpan & Connect", color = Fx.Neon) }
            }
        },
        dismissButton = { TextButton(onDismiss) { Text("Batal", color = Fx.Muted) } }
    )
}

private fun securityName(p: Int): String = when (p) {
    RdpProbe.PROTO_RDP -> tr("RDP standar")
    RdpProbe.PROTO_SSL -> "TLS"
    RdpProbe.PROTO_HYBRID -> "NLA (CredSSP)"
    RdpProbe.PROTO_RDSTLS -> "RDSTLS"
    RdpProbe.PROTO_HYBRID_EX -> "NLA (CredSSP + EarlyAuth)"
    else -> "#$p"
}

/** (judul, penjelasan) dari hasil tes handshake. */
private fun describeProbe(r: RdpProbe.Result): Pair<String, String> = when (r.status) {
    RdpProbe.Status.OK ->
        tr("Server RDP merespons") to trf("Keamanan: %s • %d ms", securityName(r.selectedProtocol), r.millis)
    RdpProbe.Status.NEGOTIATION_FAILED ->
        tr("Server menolak negosiasi") to when (r.failureCode) {
            1 -> tr("Server mewajibkan TLS.")
            2 -> tr("Server tidak mengizinkan TLS.")
            3 -> tr("Server tidak punya sertifikat TLS.")
            5 -> tr("Server mewajibkan NLA (CredSSP).")
            6 -> tr("Server mewajibkan TLS dengan autentikasi pengguna.")
            else -> trf("Kode penolakan: %d", r.failureCode)
        }
    RdpProbe.Status.NOT_RDP ->
        tr("Bukan server RDP") to tr("Ada yang menjawab di port itu, tapi bukan RDP. Cek lagi port-nya.")
    RdpProbe.Status.CONNECTION_REFUSED ->
        tr("Port ditolak") to tr("RDP belum aktif di PC itu, port salah, atau tunnel sudah mati.")
    RdpProbe.Status.TIMEOUT ->
        tr("Tidak ada respons") to tr("Timeout. Biasanya firewall, PC mati/tidur, beda jaringan tanpa VPN, atau tunnel sudah berhenti.")
    RdpProbe.Status.UNKNOWN_HOST ->
        tr("Alamat tidak ditemukan") to tr("Cek ejaan alamat dan koneksi internet kamu.")
    RdpProbe.Status.CLOSED ->
        tr("Koneksi ditutup server") to tr("Server menutup koneksi. Bisa karena batas sesi, firewall, atau tunnel.")
    RdpProbe.Status.NETWORK_ERROR ->
        tr("Masalah jaringan") to r.detail
}

/**
 * Alur Connect: tes handshake RDP yang nyata, lalu buka sesi di aplikasi RDP yang terpasang.
 * Tes gagal tidak memblokir: user tetap bisa memaksa buka (mis. server di belakang RD Gateway).
 */
@Composable
fun ConnectFlowDialog(c: SavedConnection, password: String, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var attempt by remember { mutableIntStateOf(0) }
    var result by remember { mutableStateOf<RdpProbe.Result?>(null) }
    var noApp by remember { mutableStateOf(false) }

    LaunchedEffect(attempt) {
        result = null
        result = withContext(Dispatchers.IO) { RdpProbe.test(c.host, c.port, 6000) }
    }

    fun launch(viaUri: Boolean) {
        if (AppSettings.copyPassword && password.isNotEmpty()) ExternalRdp.copyPassword(ctx, password)
        val ok = if (viaUri) ExternalRdp.openUri(ctx, c.host, c.port, c.username)
        else ExternalRdp.openFile(ctx, c.host, c.port, c.username)
        if (ok) onDismiss() else noApp = true
    }

    val r = result
    val ok = r?.status == RdpProbe.Status.OK

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Fx.Panel,
        title = { Text(c.name, color = Color.White) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${c.username.ifEmpty { "—" }} @ ${c.host}:${c.port}", color = Fx.Muted, fontSize = 12.sp)
                if (r == null) {
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(20.dp), color = Fx.Neon, strokeWidth = 2.dp)
                        Spacer(Modifier.width(10.dp))
                        Text("Mengecek server RDP…", color = Color.White, fontSize = 14.sp)
                    }
                } else {
                    val (title, detail) = describeProbe(r)
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).background(if (ok) Fx.Green else Fx.Red, CircleShape))
                        Spacer(Modifier.width(8.dp))
                        Text(title, color = if (ok) Fx.Green else Fx.Red, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    Text(detail, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                    if (!ok && c.kind == "GITHUB") {
                        Text(
                            "RDP GitHub/tunnel: pastikan workflow masih berjalan, lalu ambil alamat dan password terbaru dari lognya dan edit koneksi ini.",
                            color = Fx.Muted, fontSize = 11.sp
                        )
                    }
                    if (password.isNotEmpty()) {
                        TextButton({
                            ExternalRdp.copyPassword(ctx, password)
                            Toast.makeText(ctx, tr("Password disalin. Dihapus dari clipboard saat kamu kembali ke JAX."), Toast.LENGTH_LONG).show()
                        }) { Text("Salin password", color = Fx.Neon) }
                    }
                    if (!ok) TextButton({ launch(false) }) { Text("Tetap buka di aplikasi RDP", color = Fx.Neon) }
                    TextButton({ launch(true) }) { Text("Buka lewat link rdp:// (cadangan)", color = Fx.Muted) }
                    if (noApp) {
                        Text(
                            "Tidak ada aplikasi RDP yang bisa membuka sesi ini. Pasang Microsoft Remote Desktop dulu.",
                            color = Fx.Red, fontSize = 12.sp
                        )
                        Button(
                            { ExternalRdp.openStore(ctx) },
                            colors = ButtonDefaults.buttonColors(containerColor = Fx.Neon, contentColor = Fx.Bg)
                        ) { Text("Buka Play Store") }
                    }
                }
            }
        },
        confirmButton = {
            if (r != null) {
                if (ok) TextButton({ launch(false) }) { Text("Buka di aplikasi RDP", color = Fx.Neon, fontWeight = FontWeight.Bold) }
                else TextButton({ attempt++ }) { Text("Coba lagi", color = Fx.Neon) }
            }
        },
        dismissButton = { TextButton(onDismiss) { Text("Tutup", color = Fx.Muted) } }
    )
}

@Composable
fun PassphraseDialog(
    title: String, note: String, confirmLabel: String,
    onDismiss: () -> Unit, onConfirm: (String) -> Unit
) {
    var pass by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Fx.Panel,
        title = { Text(title, color = Color.White) },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(note, color = Fx.Muted, fontSize = 12.sp)
                FrycoField("Passphrase", pass, { pass = it }, password = true)
                Text("Passphrase tidak bisa dipulihkan kalau lupa. Catat di tempat aman.", color = Fx.Muted, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton({ onConfirm(pass) }) { Text(confirmLabel, color = Fx.Neon) } },
        dismissButton = { TextButton(onDismiss) { Text("Batal", color = Fx.Muted) } }
    )
}

/** Muncul sekali saat pertama kali dibuka, sebelum user connect. Bisa diganti lagi di More → Bahasa. */
@Composable
fun LanguageDialog(onPick: (AppLang) -> Unit) {
    AlertDialog(
        onDismissRequest = {},
        containerColor = Fx.Panel,
        title = { Text("Pilih bahasa / Choose language", color = Color.White) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                AppLang.values().forEach { l ->
                    TextButton({ onPick(l) }, Modifier.fillMaxWidth()) {
                        Text(if (l == AppLang.SYSTEM) "Ikuti sistem / System default" else l.label, color = Fx.Neon, fontSize = 15.sp)
                    }
                }
            }
        },
        confirmButton = {}
    )
}
