package com.fryco.remotedesktop

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PersistableBundle
import androidx.core.content.FileProvider
import java.io.File

/**
 * Membuka sesi RDP lewat aplikasi RDP yang terpasang (Microsoft Remote Desktop dll.).
 * Dua jalur: file .rdp (type application/rdp) dan URI rdp://. Keduanya didokumentasikan Microsoft.
 */
object ExternalRdp {
    const val MS_PACKAGE = "com.microsoft.rdc.androidx"
    private const val CLIP_LABEL = "JAX password"

    private fun start(ctx: Context, i: Intent): Boolean = try {
        if (ctx !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }

    fun openFile(ctx: Context, host: String, port: Int, user: String): Boolean {
        return try {
            val dir = File(ctx.cacheDir, "rdp").apply { mkdirs() }
            dir.listFiles()?.forEach { it.delete() }
            val file = File(dir, "jax-connection.rdp")
            file.writeText(RdpLink.buildRdpFile(host, port, user))
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
            start(
                ctx,
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/rdp")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            false
        }
    }

    fun openUri(ctx: Context, host: String, port: Int, user: String): Boolean =
        start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(RdpLink.buildRdpUri(host, port, user))))

    fun openStore(ctx: Context) {
        val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$MS_PACKAGE"))
        if (!start(ctx, market)) {
            start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$MS_PACKAGE")))
        }
    }

    /** Salin password, ditandai sensitif (Android 13+ menyembunyikan pratinjau). Dihapus lagi saat user kembali ke JAX. */
    fun copyPassword(ctx: Context, password: String) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(CLIP_LABEL, password)
        if (Build.VERSION.SDK_INT >= 33) {
            clip.description.extras = PersistableBundle().apply {
                putBoolean("android.content.extra.IS_SENSITIVE", true)
            }
        }
        cm.setPrimaryClip(clip)
    }

    /** Dipanggil saat JAX kembali ke layar: hapus password dari clipboard kalau itu salinan kita. */
    fun clearCopiedPassword(ctx: Context) {
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            if (cm.primaryClipDescription?.label == CLIP_LABEL) {
                if (Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip() else cm.setPrimaryClip(ClipData.newPlainText("", ""))
            }
        } catch (e: Exception) {
        }
    }
}
